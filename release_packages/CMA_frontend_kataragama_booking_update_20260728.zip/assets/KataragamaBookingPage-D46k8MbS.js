import{n as e,s as t,t as n}from"./jsx-runtime-B7FaSiYN.js";import{B as r,J as i,L as a,Y as o,ht as s,o as ee,pt as te,r as ne,s as re,t as ie,yt as ae}from"./index-DDeNPf1d.js";import{Ar as oe,Bt as se,H as ce,Jt as le,Qr as ue,Qt as de,Rt as fe,St as pe,et as c,f as me,gn as he,ii as ge,m as _e,mi as ve,nr as ye,t as be}from"./lucide-react-9y6k2CI2.js";import{t as l}from"./T-DBWQI5To.js";var u=t(e(),1);ie(),be(),ee(),s();var d=n();function f(){let{t:e}=ne(),{citizen:t,isCitizenLoggedIn:n}=re(),[s,ee]=(0,u.useState)([]),[ie,be]=(0,u.useState)(!0),[f,xe]=(0,u.useState)(`guest`),[p,m]=(0,u.useState)(null),[h,g]=(0,u.useState)(null),[_,Se]=(0,u.useState)(``),[Ce,we]=(0,u.useState)(``),[v,y]=(0,u.useState)([]),Te=e=>{v.some(t=>t.id===e.id)?y([]):y([e])},[Ee,De]=(0,u.useState)(2),[Oe,ke]=(0,u.useState)(0),[b,Ae]=(0,u.useState)(new Date),[x,je]=(0,u.useState)({}),[Me,Ne]=(0,u.useState)(!1),[Pe,S]=(0,u.useState)(!1),[C,w]=(0,u.useState)(1),[T,Fe]=(0,u.useState)(!1),[Ie,E]=(0,u.useState)(``),[D,O]=(0,u.useState)(null),[k,Le]=(0,u.useState)(``),[A,Re]=(0,u.useState)(``),[j,ze]=(0,u.useState)(``),[M,Be]=(0,u.useState)(``),[N,Ve]=(0,u.useState)(``),[He,Ue]=(0,u.useState)(``),[We,Ge]=(0,u.useState)(``),[P,Ke]=(0,u.useState)(``),[F,qe]=(0,u.useState)(``),[I,Je]=(0,u.useState)(``),[L,Ye]=(0,u.useState)(!1),[R,Xe]=(0,u.useState)(0),[z,B]=(0,u.useState)([]),[Ze,Qe]=(0,u.useState)(!1),[V,$e]=(0,u.useState)(()=>localStorage.getItem(`ktgb_reference`)||``),[H,et]=(0,u.useState)(()=>localStorage.getItem(`ktgb_phone`)||``),[U,W]=(0,u.useState)(null),[G,tt]=(0,u.useState)(!1),[nt,K]=(0,u.useState)(``),[q,J]=(0,u.useState)(`card`),[rt,it]=(0,u.useState)(``),[at,ot]=(0,u.useState)(``),[st,ct]=(0,u.useState)(``),[lt,ut]=(0,u.useState)(``),[dt,ft]=(0,u.useState)([``,``,``,``,``,``]),[pt,mt]=(0,u.useState)(60),ht=(0,u.useRef)([]),Y=async()=>{Ne(!0);try{let e=await i();e.data&&e.data.status===`success`&&je(e.data.data)}catch(e){console.error(`Failed to fetch booking availability:`,e)}finally{Ne(!1)}},gt=async()=>{be(!0);try{ee((await o()).data?.data||[])}catch(e){console.error(`Failed to fetch rooms list:`,e)}finally{be(!1)}};(0,u.useEffect)(()=>{Y(),gt()},[]),(0,u.useEffect)(()=>{if(t){let e=t.name.split(` `);Le(e[0]||``),Re(e.slice(1).join(` `)||``),Ve(t.email||``),Be(t.phone||``),ze(t.nic||``)}},[t]);let X=(()=>{if(!p||!h)return 0;let e=Math.abs(h.getTime()-p.getTime())/(1e3*60*60);return Math.max(1,Math.ceil(e/24))})(),Z=e=>{if(!e)return 0;let t=e.emp_price===void 0?e.empPrice:e.emp_price;return f===`employee`?t:e.price},Q=()=>v.length===0||X===0?0:v.reduce((e,t)=>e+Z(t),0)*X,_t=e=>new Date(e.getFullYear(),e.getMonth()+1,0).getDate(),vt=e=>new Date(e.getFullYear(),e.getMonth(),1).getDay(),yt=()=>{Ae(new Date(b.getFullYear(),b.getMonth()-1,1))},bt=()=>{Ae(new Date(b.getFullYear(),b.getMonth()+1,1))},xt=(e,t,n)=>`${e}-${String(t+1).padStart(2,`0`)}-${String(n).padStart(2,`0`)}`,$=e=>e?e.toLocaleDateString(`en-GB`,{day:`numeric`,month:`short`,year:`numeric`,hour:`2-digit`,minute:`2-digit`}):`Select date & time`,St=()=>{if(!p||!h)return!1;let e=new Date(p),t=new Date(h);for(e.toDateString()!==t.toDateString()&&t.setDate(t.getDate()-1);e<=t;){if(x[xt(e.getFullYear(),e.getMonth(),e.getDate())]===`booked`)return!0;e.setDate(e.getDate()+1)}return!1},Ct=()=>{if(St()){window.alert(`One or more selected dates are already booked. Please select another stay period.`);return}O(null),E(``),w(1),S(!0)},wt=async e=>{let t=e.target.files[0];if(t){Qe(!0);try{Je((await r(t)).data.path),alert(`Official letter uploaded successfully!`)}catch(e){console.error(e),alert(`Failed to upload file. Please try again.`)}finally{Qe(!1)}}},Tt=()=>{B([...z,{name:``,nic:``}]),Xe(e=>e+1)},Et=e=>{let t=[...z];t.splice(e,1),B(t),Xe(e=>Math.max(0,e-1))},Dt=(e,t,n)=>{let r=[...z];r[e]={...r[e],[t]:n},B(r)},Ot=(e,t)=>{let n=e.target.value.replace(/\D/g,``).slice(-1),r=[...dt];r[t]=n,ft(r),n&&t<5&&ht.current[t+1]?.focus()},kt=(e,t)=>{e.key===`Backspace`&&!dt[t]&&t>0&&ht.current[t-1]?.focus()},At=async()=>{Fe(!0),E(``);try{let e=v.map(e=>ae({guest_name:`${k} ${A}`.trim(),email:N,phone:M,nic:j,employee_id:f===`employee`?He:null,unit_number:e.name,check_in:_.replace(`T`,` `),check_out:Ce.replace(`T`,` `),adults:Number(Ee),children:Number(Oe),amount:Z(e)*X,notes:We,permanent_address:P,occupation:F,gov_letter:I||null,is_cma_employee:!!L,family_count:Number(R),family_members:z})),t=await Promise.all(e),n=t[0];if(n.data&&n.data.status===`success`){let e=t.map(e=>e.data.data),r=e.map(e=>e.reference_no);O({...n.data.data,unit_number:v.map(e=>e.name).join(`, `),amount:Q(),allReferences:r.join(`, `),allBookings:e}),localStorage.setItem(`ktgb_reference`,r[0]),localStorage.setItem(`ktgb_phone`,M),$e(r[0]),et(M),W({reference_no:r[0],booking_status:`Pending`,payment_status:`Pending`,message:`Payment and administrator approval are pending.`}),w(5),Y()}}catch(e){E(e?.response?.data?.message||e?.response?.data?.error||`An error occurred during booking. Please try again.`),w(1)}finally{Fe(!1)}},jt=async()=>{if(!V||!H){K(`Enter your booking reference number and phone number.`);return}tt(!0),K(``);try{let e=await a(V.trim().toUpperCase(),H.trim());W(e.data.data),O(t=>t&&{...t,...e.data.data}),localStorage.setItem(`ktgb_reference`,V.trim().toUpperCase()),localStorage.setItem(`ktgb_phone`,H.trim()),e.data.data?.booking_status===`Confirmed`&&Y()}catch(e){W(null),K(e?.response?.data?.message||`Unable to check this booking right now.`)}finally{tt(!1)}},Mt=e=>{ot(e.target.value.replace(/\D/g,``).slice(0,16).replace(/(.{4})/g,`$1 `).trim())},Nt=e=>{let t=e.target.value.replace(/\D/g,``).slice(0,4);ct(t.length>2?`${t.slice(0,2)}/${t.slice(2)}`:t)},Pt=()=>At(),Ft=_t(b),It=vt(b),Lt=b.toLocaleString(`default`,{month:`long`,year:`numeric`}),Rt=[];for(let e=0;e<It;e++)Rt.push({day:null,empty:!0});for(let e=1;e<=Ft;e++){let t=x[xt(b.getFullYear(),b.getMonth(),e)]||`available`,n=new Date(b.getFullYear(),b.getMonth(),e),r=!1,i=!1,a=!1,o=new Date().toDateString()===n.toDateString();if(p&&h){let e=p.getTime(),t=h.getTime(),o=n.getTime();o===e?r=!0:o===t?i=!0:o>e&&o<t&&(a=!0)}else p&&p.getTime()===n.getTime()&&(r=!0);Rt.push({day:e,empty:!1,status:t,isSelected:r,isCheckoutDay:i,isInRange:a,isToday:o,date:n})}return(0,d.jsxs)(`div`,{style:{background:`var(--off-white)`,minHeight:`100vh`,paddingBottom:`4rem`},children:[(0,d.jsxs)(`section`,{className:`bk-hero`,children:[(0,d.jsx)(`div`,{className:`bk-hero-bg`}),(0,d.jsx)(`div`,{className:`bk-hero-overlay`}),(0,d.jsxs)(`div`,{className:`bk-hero-inner`,children:[(0,d.jsxs)(`div`,{className:`bk-hero-left`,children:[(0,d.jsxs)(`div`,{className:`bk-hero-eyebrow`,children:[(0,d.jsx)(ge,{size:12,style:{marginRight:`4px`,verticalAlign:`middle`}}),`CMA Circuit Bungalow · Kataragama`]}),(0,d.jsxs)(`h1`,{className:`bk-hero-title`,style:{marginTop:`10px`},children:[`Serene Retreat in`,(0,d.jsx)(`br`,{}),(0,d.jsx)(`em`,{children:`Sacred Kataragama`})]}),(0,d.jsx)(`p`,{className:`bk-hero-desc`,children:(0,d.jsx)(l,{children:`Reserve your stay at the Condominium Management Authority's exclusive circuit bungalow — nestled in the heart of Kataragama, offering tranquil accommodation for staff and visiting guests.`})})]}),(0,d.jsxs)(`div`,{className:`bk-hero-gallery`,children:[(0,d.jsx)(`div`,{className:`bk-gallery-img`,children:(0,d.jsx)(`img`,{src:`https://media-cdn.tripadvisor.com/media/photo-s/02/e0/70/a5/gem-river-edge-eco-home.jpg`,alt:`Kataragama Bungalow Exterior`})}),(0,d.jsx)(`div`,{className:`bk-gallery-img`,children:(0,d.jsx)(`img`,{src:`https://scontent.fcmb1-2.fna.fbcdn.net/v/t1.6435-9/126420775_3373655879526837_7821034308813852164_n.jpg?stp=dst-jpg_s720x720_tt6&_nc_cat=105&ccb=1-7&_nc_sid=536f4a&_nc_ohc=6Em481u_fMsQ7kNvwF96b4W&_nc_oc=Adrl-T0oCfLcKv8qUlTmK__jLBVhnbJ7bJuKHTUigBn7ErJQYtWS8QPsSE9X7BVru8g&_nc_zt=23&_nc_ht=scontent.fcmb1-2.fna&_nc_gid=6NzPiXPSvoMCYsyqE1bduA&_nc_ss=78289&oh=00_Af8jNNXtdz07lJe2kKCi7bPMCQlzcf_mazyI1FuCJfdVHw&oe=6A4870E0`,alt:`Bungalow Living Room`})}),(0,d.jsx)(`div`,{className:`bk-gallery-img`,children:(0,d.jsx)(`img`,{src:`https://st5.depositphotos.com/19085394/64942/i/450/depositphotos_649426038-stock-photo-kirivehara-kiri-vehera-shrine-kataragama.jpg`,alt:`Kataragama Kiri Vehera Temple`})})]})]})]}),(0,d.jsx)(`div`,{className:`role-selector-sec`,children:(0,d.jsx)(`div`,{className:`role-selector-inner`,children:(0,d.jsxs)(`div`,{className:`role-row`,children:[(0,d.jsx)(`span`,{className:`role-label`,children:(0,d.jsx)(l,{children:`I am a:`})}),(0,d.jsxs)(`button`,{className:`role-btn${f===`guest`?` active`:``}`,onClick:()=>{xe(`guest`),y([])},children:[(0,d.jsx)(_e,{size:14}),`Visiting Guest`,(0,d.jsx)(`span`,{className:`role-badge`,children:(0,d.jsx)(l,{children:`Public`})})]}),(0,d.jsxs)(`span`,{style:{marginLeft:`auto`,fontSize:`12.5px`,color:`var(--text-muted)`,display:`flex`,alignItems:`center`,gap:`4px`},children:[(0,d.jsx)(c,{size:14,style:{color:`var(--success)`}}),`Secure Booking Portal · Condominium Management Authority`]})]})})}),(0,d.jsx)(`div`,{style:{maxWidth:`1280px`,margin:`0 auto`,padding:`40px 24px`},children:(0,d.jsxs)(`div`,{className:`booking-layout`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`avail-card`,style:{padding:`24px`,borderRadius:`12px`,background:`#fff`,border:`1px solid #eee`,boxShadow:`var(--shadow-sm)`,marginBottom:`30px`},children:[(0,d.jsxs)(`h3`,{style:{margin:`0 0 20px 0`,display:`flex`,alignItems:`center`,gap:`8px`,borderBottom:`1px solid #eee`,paddingBottom:`12px`,color:`var(--text-dark)`},children:[(0,d.jsx)(ue,{size:18,style:{color:`var(--crimson)`}}),`Select Stay Period & Check Availability`]}),(0,d.jsxs)(`div`,{className:`bk-availability-grid`,style:{display:`grid`,gridTemplateColumns:`1.2fr 1fr`,gap:`30px`},children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{style:{background:`rgba(139, 0, 0, 0.05)`,border:`1px solid rgba(139, 0, 0, 0.15)`,borderRadius:`8px`,padding:`12px 16px`,marginBottom:`20px`,display:`flex`,alignItems:`flex-start`,gap:`10px`},children:[(0,d.jsx)(he,{size:16,style:{color:`var(--crimson)`,marginTop:`2px`,flexShrink:0}}),(0,d.jsxs)(`div`,{style:{fontSize:`13px`,color:`#555`,lineHeight:`1.4`},children:[(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`Bungalow Stay Policy:`})}),` Check-in is fixed at `,(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`1:00 PM`})}),` on the arrival date, and check-out is fixed at `,(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`10:00 AM`})}),` on the departure date. This stay period is automatically calculated as one day.`]})]}),(0,d.jsxs)(`div`,{className:`bk-dates-input-grid`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:`20px`,marginBottom:`20px`},children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`label`,{htmlFor:`checkin-date`,style:{display:`block`,fontWeight:600,fontSize:`13px`,color:`var(--text-dark)`,marginBottom:`8px`},children:`Check-in Date *`}),(0,d.jsxs)(`div`,{style:{position:`relative`,display:`flex`,alignItems:`center`},children:[(0,d.jsx)(`input`,{id:`checkin-date`,name:`checkin-date`,type:`date`,className:`bk-form-input`,style:{width:`100%`,padding:`10px 14px`,paddingRight:`80px`,borderRadius:`8px`,border:`1px solid #ddd`,fontSize:`14px`,background:`#fff`,color:`var(--text-dark)`},value:_.split(`T`)[0]||``,onChange:e=>{let t=e.target.value;if(t){if(x[t]===`booked`){window.alert(`This date is already booked. Please select another date.`);return}let e=`${t}T13:00`;Se(e),m(new Date(e))}else Se(``),m(null)},min:new Date().toISOString().split(`T`)[0]}),(0,d.jsx)(`span`,{style:{position:`absolute`,right:`12px`,fontSize:`12px`,color:`var(--crimson)`,fontWeight:`700`,pointerEvents:`none`},children:(0,d.jsx)(l,{children:`1:00 PM`})})]})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`label`,{htmlFor:`checkout-date`,style:{display:`block`,fontWeight:600,fontSize:`13px`,color:`var(--text-dark)`,marginBottom:`8px`},children:`Check-out Date *`}),(0,d.jsxs)(`div`,{style:{position:`relative`,display:`flex`,alignItems:`center`},children:[(0,d.jsx)(`input`,{id:`checkout-date`,name:`checkout-date`,type:`date`,className:`bk-form-input`,style:{width:`100%`,padding:`10px 14px`,paddingRight:`80px`,borderRadius:`8px`,border:`1px solid #ddd`,fontSize:`14px`,background:`#fff`,color:`var(--text-dark)`},value:Ce.split(`T`)[0]||``,onChange:e=>{let t=e.target.value;if(t){if(x[t]===`booked`){window.alert(`This date is already booked. Please select another date.`);return}let e=`${t}T10:00`;we(e),g(new Date(e))}else we(``),g(null)},min:_?_.split(`T`)[0]:new Date().toISOString().split(`T`)[0]}),(0,d.jsx)(`span`,{style:{position:`absolute`,right:`12px`,fontSize:`12px`,color:`var(--crimson)`,fontWeight:`700`,pointerEvents:`none`},children:(0,d.jsx)(l,{children:`10:00 AM`})})]})]})]}),p&&h&&(0,d.jsxs)(`div`,{style:{background:`rgba(201, 162, 39, 0.1)`,border:`1px solid rgba(201, 162, 39, 0.3)`,borderRadius:`8px`,padding:`12px 16px`,display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`8px`,fontSize:`13.5px`,color:`var(--text-dark)`},children:[(0,d.jsx)(he,{size:16,style:{color:`#C9A227`}}),(0,d.jsx)(`span`,{children:(0,d.jsx)(l,{children:`Staying Duration:`})}),(0,d.jsxs)(`strong`,{children:[X,` Day(s)`]})]}),(0,d.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`(Calculated automatically)`})})]})]}),(0,d.jsxs)(`div`,{style:{borderLeft:`1px solid #eee`,paddingLeft:`30px`},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:`12px`},children:[(0,d.jsx)(`span`,{style:{fontWeight:700,fontSize:`13.5px`,color:`var(--text-dark)`},children:(0,d.jsx)(l,{children:`Availability Calendar`})}),(0,d.jsxs)(`div`,{style:{display:`flex`,gap:`4px`,alignItems:`center`},children:[(0,d.jsx)(`button`,{type:`button`,style:{padding:`2px 8px`,background:`none`,border:`1px solid #ddd`,borderRadius:`4px`,cursor:`pointer`,fontSize:`12px`},onClick:yt,children:`◀`}),(0,d.jsx)(`span`,{style:{fontSize:`12px`,fontWeight:`600`,minWidth:`90px`,textAlign:`center`,display:`inline-block`},children:Lt}),(0,d.jsx)(`button`,{type:`button`,style:{padding:`2px 8px`,background:`none`,border:`1px solid #ddd`,borderRadius:`4px`,cursor:`pointer`,fontSize:`12px`},onClick:bt,children:`▶`})]})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`4px`},children:[(0,d.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(7, 1fr)`,textAlign:`center`,fontSize:`11px`,fontWeight:`700`,color:`var(--text-muted)`},children:[(0,d.jsx)(`span`,{children:(0,d.jsx)(l,{children:`S`})}),(0,d.jsx)(`span`,{children:(0,d.jsx)(l,{children:`M`})}),(0,d.jsx)(`span`,{children:(0,d.jsx)(l,{children:`T`})}),(0,d.jsx)(`span`,{children:(0,d.jsx)(l,{children:`W`})}),(0,d.jsx)(`span`,{children:(0,d.jsx)(l,{children:`T`})}),(0,d.jsx)(`span`,{children:(0,d.jsx)(l,{children:`F`})}),(0,d.jsx)(`span`,{children:(0,d.jsx)(l,{children:`S`})})]}),(0,d.jsx)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(7, 1fr)`,gap:`4px`},children:Rt.map((e,t)=>{if(e.empty)return(0,d.jsx)(`div`,{style:{height:`24px`}},`tiny-empty-${t}`);let n=e.status===`booked`,r=e.status===`partial`,i=`#eaf5ee`,a=`#2e6b4a`,o=`Available`;return n?(i=`#fbebeb`,a=`#c93b3b`,o=`Booked`):r&&(i=`#fff4eb`,a=`#d4622a`,o=`Partial`),(0,d.jsx)(`div`,{title:`Day ${e.day}: ${o}`,style:{height:`26px`,display:`flex`,alignItems:`center`,justifyContent:`center`,borderRadius:`6px`,fontSize:`11.5px`,fontWeight:`600`,background:i,color:a,border:e.isToday?`1px solid #C9A227`:`none`,position:`relative`},children:e.day},`tiny-day-${e.day}`)})})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,gap:`12px`,justifyContent:`center`,marginTop:`16px`,fontSize:`11px`},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`4px`},children:[(0,d.jsx)(`div`,{style:{width:8,height:8,borderRadius:`50%`,background:`#2e6b4a`}}),` Available`]}),(0,d.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`4px`},children:[(0,d.jsx)(`div`,{style:{width:8,height:8,borderRadius:`50%`,background:`#d4622a`}}),` Partial`]}),(0,d.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`4px`},children:[(0,d.jsx)(`div`,{style:{width:8,height:8,borderRadius:`50%`,background:`#c93b3b`}}),` Booked`]})]})]})]})]}),(0,d.jsxs)(`div`,{className:`rooms-sec`,children:[(0,d.jsx)(`div`,{className:`rooms-sec-head`,children:(0,d.jsx)(`h3`,{style:{margin:0},children:(0,d.jsx)(l,{children:`Select Your Room`})})}),(0,d.jsx)(`div`,{className:`rooms-grid`,children:ie?(0,d.jsx)(`div`,{style:{gridColumn:`1 / -1`,textAlign:`center`,padding:`3rem`,color:`var(--text-muted)`},children:`Loading available guesthouse rooms...`}):s.length===0?(0,d.jsx)(`div`,{style:{gridColumn:`1 / -1`,textAlign:`center`,padding:`3rem`,color:`var(--text-muted)`},children:`No rooms configured at this time.`}):s.map(e=>{let t=v.some(t=>t.id===e.id),n=Z(e);return(0,d.jsxs)(`div`,{className:`room-card${t?` selected-room`:``}`,onClick:()=>Te(e),children:[e.image?(0,d.jsx)(`img`,{src:e.image.startsWith(`http`)?e.image:te(e.image),alt:e.name,className:`room-img`,onError:e=>{e.target.style.display=`none`,e.target.nextSibling.style.display=`flex`}}):null,(0,d.jsx)(`div`,{className:`room-img-placeholder`,style:{display:e.image?`none`:`flex`,fontSize:`2.5rem`},children:e.emoji||`🛏️`}),(0,d.jsxs)(`div`,{className:`room-body`,children:[(0,d.jsx)(`h4`,{className:`room-name`,style:{margin:0},children:e.name}),(0,d.jsxs)(`div`,{className:`room-meta`,style:{marginTop:`8px`},children:[(0,d.jsxs)(`div`,{className:`room-meta-item`,children:[(0,d.jsx)(ve,{size:13}),` `,e.beds]}),(0,d.jsxs)(`div`,{className:`room-meta-item`,children:[(0,d.jsx)(me,{size:13}),` `,e.capacity]}),e.ac&&(0,d.jsxs)(`div`,{className:`room-meta-item`,children:[(0,d.jsx)(ce,{size:13}),` A/C`]}),(0,d.jsxs)(`div`,{className:`room-meta-item`,children:[(0,d.jsx)(ye,{size:13}),` `,e.view]})]}),(0,d.jsx)(`div`,{className:`room-price-row`,style:{marginTop:`16px`},children:(0,d.jsxs)(`div`,{className:`room-price`,children:[`Rs. `,Number(n).toLocaleString(),(0,d.jsxs)(`span`,{style:{fontSize:`11px`,color:`var(--text-muted)`,fontWeight:400},children:[` `,`/ night `,f===`employee`&&`(Staff)`]})]})}),(0,d.jsx)(`button`,{className:`room-select-btn`,type:`button`,onClick:t=>{t.stopPropagation(),Te(e)},children:t?`✓ Selected`:`Select Room`})]})]},e.id)})})]})]}),(0,d.jsxs)(`div`,{className:`booking-sidebar`,children:[(0,d.jsxs)(`div`,{className:`bk-summary-card`,children:[(0,d.jsxs)(`div`,{className:`bk-sum-head`,children:[(0,d.jsx)(`h4`,{style:{margin:0},children:(0,d.jsx)(l,{children:`Booking Summary`})}),(0,d.jsx)(`p`,{style:{margin:`4px 0 0`,fontSize:`11.5px`,opacity:.85},children:(0,d.jsx)(l,{children:`Review your reservation`})})]}),(0,d.jsxs)(`div`,{className:`bk-sum-body`,children:[(0,d.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,d.jsx)(`span`,{className:`bk-sum-label`,children:(0,d.jsx)(l,{children:`Property`})}),(0,d.jsx)(`span`,{className:`bk-sum-value`,children:(0,d.jsx)(l,{children:`Kataragama Bungalow`})})]}),(0,d.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,d.jsx)(`span`,{className:`bk-sum-label`,children:(0,d.jsx)(l,{children:`Room(s)`})}),(0,d.jsx)(`span`,{className:`bk-sum-value`,children:v.length>0?v.map(e=>e.name).join(`, `):`Not selected`})]}),(0,d.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,d.jsx)(`span`,{className:`bk-sum-label`,children:(0,d.jsx)(l,{children:`Check-In`})}),(0,d.jsx)(`span`,{className:`bk-sum-value`,children:$(p)})]}),(0,d.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,d.jsx)(`span`,{className:`bk-sum-label`,children:(0,d.jsx)(l,{children:`Check-Out`})}),(0,d.jsx)(`span`,{className:`bk-sum-value`,children:$(h)})]}),(0,d.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,d.jsx)(`span`,{className:`bk-sum-label`,children:(0,d.jsx)(l,{children:`Nights`})}),(0,d.jsx)(`span`,{className:`bk-sum-value`,children:X>0?`${X} night${X>1?`s`:``}`:`—`})]}),(0,d.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,d.jsx)(`span`,{className:`bk-sum-label`,children:(0,d.jsx)(l,{children:`Guests`})}),(0,d.jsxs)(`span`,{className:`bk-sum-value`,children:[Ee,` Adult(s), `,Oe,` Child(ren)`]})]}),v.length>0&&(0,d.jsxs)(`div`,{className:`bk-sum-row`,style:{flexDirection:`column`,alignItems:`flex-start`,gap:`4px`},children:[(0,d.jsx)(`span`,{className:`bk-sum-label`,children:f===`employee`?`Staff Rate/Night`:`Rate/Night`}),(0,d.jsx)(`div`,{style:{width:`100%`,paddingLeft:`8px`,fontSize:`12px`,color:`var(--text-muted)`},children:v.map(e=>(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,d.jsxs)(`span`,{children:[e.name,`:`]}),(0,d.jsxs)(`span`,{children:[`Rs. `,Z(e).toLocaleString()]})]},e.id))})]}),(0,d.jsxs)(`div`,{className:`bk-sum-total`,children:[(0,d.jsx)(`span`,{className:`bk-sum-total-label`,children:(0,d.jsx)(l,{children:`Total Amount`})}),(0,d.jsxs)(`span`,{className:`bk-sum-total-val`,children:[`Rs. `,Q().toLocaleString()]})]}),(0,d.jsxs)(`button`,{className:`bk-proceed-btn`,type:`button`,onClick:Ct,disabled:v.length===0||!p||!h||X<=0,children:[(0,d.jsx)(le,{size:15}),`Proceed to Book`]}),(0,d.jsxs)(`div`,{className:`bk-trust-items`,style:{marginTop:`16px`},children:[(0,d.jsxs)(`div`,{className:`bk-trust-item`,children:[(0,d.jsx)(c,{size:14,style:{color:`var(--success)`}}),` Secure SSL Booking`]}),(0,d.jsxs)(`div`,{className:`bk-trust-item`,children:[(0,d.jsx)(c,{size:14,style:{color:`var(--success)`}}),` Free Cancellation 48hrs prior`]}),(0,d.jsxs)(`div`,{className:`bk-trust-item`,children:[(0,d.jsx)(c,{size:14,style:{color:`var(--success)`}}),` Admin-reviewed reservation`]})]})]})]}),(0,d.jsxs)(`div`,{style:{background:`#fff`,borderRadius:`12px`,border:`1px solid #eee`,padding:`20px`,boxShadow:`var(--shadow-sm)`,marginBottom:`20px`},children:[(0,d.jsxs)(`div`,{style:{fontWeight:700,display:`flex`,alignItems:`center`,gap:`6px`,color:`var(--text-dark)`,marginBottom:`6px`},children:[(0,d.jsx)(oe,{size:16,style:{color:`var(--crimson)`}}),`Check Booking Status`]}),(0,d.jsx)(`p`,{style:{margin:`0 0 12px`,color:`var(--text-muted)`,fontSize:`12px`,lineHeight:1.5},children:`Enter the reference and phone number used for your request.`}),(0,d.jsx)(`input`,{className:`bk-form-input`,placeholder:`KTGB008723`,value:V,onChange:e=>$e(e.target.value.toUpperCase()),style:{marginBottom:`8px`}}),(0,d.jsx)(`input`,{className:`bk-form-input`,placeholder:`Phone number`,value:H,onChange:e=>et(e.target.value),style:{marginBottom:`8px`}}),(0,d.jsxs)(`button`,{type:`button`,className:`bk-proceed-btn`,onClick:jt,disabled:G,children:[G?(0,d.jsx)(de,{size:15,style:{animation:`spin 1s linear infinite`}}):(0,d.jsx)(ye,{size:15}),`Check Status`]}),nt&&(0,d.jsx)(`div`,{style:{marginTop:`10px`,color:`#b91c1c`,fontSize:`12px`},children:nt}),U&&(0,d.jsxs)(`div`,{style:{marginTop:`12px`,padding:`12px`,borderRadius:`8px`,background:U.booking_status===`Confirmed`?`#ecfdf5`:U.booking_status===`Cancelled`?`#fef2f2`:`#fffbeb`,border:`1px solid #e5e7eb`,fontSize:`12px`,lineHeight:1.6},children:[(0,d.jsx)(`strong`,{style:{display:`block`,color:U.booking_status===`Confirmed`?`#15803d`:U.booking_status===`Cancelled`?`#b91c1c`:`#b45309`},children:U.booking_status===`Confirmed`?`Booking Successful`:U.booking_status===`Cancelled`?`Booking Not Approved`:`Pending Approval`}),(0,d.jsxs)(`div`,{children:[`Reference: `,(0,d.jsx)(`b`,{children:U.reference_no})]}),(0,d.jsxs)(`div`,{children:[`Payment: `,(0,d.jsx)(`b`,{children:U.payment_status})]}),(0,d.jsx)(`div`,{children:U.message})]})]}),(0,d.jsxs)(`div`,{style:{background:`#fff`,borderRadius:`12px`,border:`1px solid #eee`,padding:`20px`,boxShadow:`var(--shadow-sm)`},children:[(0,d.jsxs)(`div`,{style:{fontWeight:700,display:`flex`,alignItems:`center`,gap:`6px`,color:`var(--text-dark)`,marginBottom:`12px`},children:[(0,d.jsx)(pe,{size:14,style:{color:`var(--crimson)`}}),`Need Booking Assistance?`]}),(0,d.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`,fontSize:`13px`,color:`var(--text-muted)`},children:[(0,d.jsx)(`div`,{children:`📞 0112447432`}),(0,d.jsx)(`div`,{children:`✉ bungalow@condominium.lk`}),(0,d.jsx)(`div`,{children:`🕒 Mon–Fri, 8:30am–4:30pm`})]})]}),(0,d.jsxs)(`div`,{style:{background:`#fff`,borderRadius:`12px`,border:`1px solid #eee`,padding:`20px`,boxShadow:`var(--shadow-sm)`,marginTop:`20px`},children:[(0,d.jsxs)(`div`,{style:{fontWeight:700,display:`flex`,alignItems:`center`,gap:`6px`,color:`var(--text-dark)`,marginBottom:`12px`},children:[(0,d.jsx)(se,{size:14,style:{color:`var(--crimson)`}}),`Bungalow Location`]}),(0,d.jsx)(`p`,{style:{margin:`0 0 12px 0`,fontSize:`13px`,color:`var(--text-muted)`,lineHeight:`1.4`},children:(0,d.jsx)(l,{children:`Detour Road, Kataragama, Sri Lanka. Conveniently situated close to the sacred temples.`})}),(0,d.jsxs)(`a`,{href:`https://maps.app.goo.gl/PkPj7oFnBFLMbA9n7`,target:`_blank`,rel:`noopener noreferrer`,style:{display:`flex`,alignItems:`center`,justifyContent:`center`,gap:`6px`,textDecoration:`none`,backgroundColor:`var(--crimson)`,color:`#fff`,border:`none`,borderRadius:`6px`,padding:`8px 12px`,fontSize:`13px`,fontWeight:`600`,transition:`background-color 0.2s ease`,cursor:`pointer`},onMouseOver:e=>e.currentTarget.style.backgroundColor=`#6b0000`,onMouseOut:e=>e.currentTarget.style.backgroundColor=`var(--crimson)`,children:[(0,d.jsx)(fe,{size:14}),`View on Google Maps`]})]})]})]})}),(0,d.jsx)(`section`,{className:`section facilities-sec`,children:(0,d.jsxs)(`div`,{className:`container`,children:[(0,d.jsxs)(`div`,{style:{textAlign:`center`,marginBottom:`40px`},children:[(0,d.jsx)(`span`,{className:`section-label`,children:(0,d.jsx)(l,{children:`Amenities`})}),(0,d.jsx)(`h2`,{className:`section-title`,children:(0,d.jsx)(l,{children:`Bungalow Facilities`})}),(0,d.jsx)(`p`,{className:`section-subtitle`,style:{margin:`0 auto`},children:(0,d.jsx)(l,{children:`Enjoy standard facilities at the CMA Circuit Bungalow — designed for a comfortable retreat.`})})]}),(0,d.jsxs)(`div`,{className:`facilities-grid`,children:[(0,d.jsxs)(`div`,{className:`facility-card`,children:[(0,d.jsx)(`span`,{className:`facility-icon`,children:`🛏️`}),(0,d.jsx)(`h4`,{className:`facility-name`,children:(0,d.jsx)(l,{children:`Comfortable Rooms`})}),(0,d.jsx)(`p`,{className:`facility-desc`,children:(0,d.jsx)(l,{children:`Quality beds, linen, hot water showers, and optional AC setups.`})})]}),(0,d.jsxs)(`div`,{className:`facility-card`,children:[(0,d.jsx)(`span`,{className:`facility-icon`,children:`🍽️`}),(0,d.jsx)(`h4`,{className:`facility-name`,children:(0,d.jsx)(l,{children:`Dining Hall`})}),(0,d.jsx)(`p`,{className:`facility-desc`,children:(0,d.jsx)(l,{children:`Spacious seating with kitchen setups available for visiting guests.`})})]}),(0,d.jsxs)(`div`,{className:`facility-card`,children:[(0,d.jsx)(`span`,{className:`facility-icon`,children:`🌿`}),(0,d.jsx)(`h4`,{className:`facility-name`,children:(0,d.jsx)(l,{children:`Surrounding Gardens`})}),(0,d.jsx)(`p`,{className:`facility-desc`,children:(0,d.jsx)(l,{children:`Beautiful lush courtyard garden surrounding the premises.`})})]}),(0,d.jsxs)(`div`,{className:`facility-card`,children:[(0,d.jsx)(`span`,{className:`facility-icon`,children:`🅿️`}),(0,d.jsx)(`h4`,{className:`facility-name`,children:(0,d.jsx)(l,{children:`Free Vehicle Parking`})}),(0,d.jsx)(`p`,{className:`facility-desc`,children:(0,d.jsx)(l,{children:`On-site secure parking space inside the gated boundaries.`})})]})]})]})}),Pe&&(0,d.jsx)(`div`,{className:`bk-modal-overlay open`,children:(0,d.jsxs)(`div`,{className:`bk-modal`,children:[(0,d.jsxs)(`div`,{className:`bk-modal-head`,children:[(0,d.jsx)(`span`,{className:`bk-modal-title`,children:(0,d.jsx)(l,{children:`Complete Reservation`})}),(0,d.jsx)(`button`,{className:`bk-modal-close`,onClick:()=>S(!1),children:`✕`})]}),(0,d.jsxs)(`div`,{className:`bk-modal-body`,children:[(0,d.jsxs)(`div`,{className:`bk-steps`,style:{justifyContent:`center`,gap:`40px`},children:[(0,d.jsxs)(`div`,{className:`bk-step${C>=1?` active`:``}${C>1?` done`:``}`,children:[(0,d.jsx)(`div`,{className:`bk-step-circle`,children:`1`}),(0,d.jsx)(`div`,{className:`bk-step-label`,children:`Guest Info`})]}),(0,d.jsxs)(`div`,{className:`bk-step${C===5?` active`:``}`,children:[(0,d.jsx)(`div`,{className:`bk-step-circle`,children:`✓`}),(0,d.jsx)(`div`,{className:`bk-step-label`,children:`Done`})]})]}),C===1&&(0,d.jsxs)(`div`,{className:`bk-form-section active`,children:[(0,d.jsx)(`h4`,{style:{margin:`0 0 16px`,fontWeight:700},children:(0,d.jsx)(l,{children:`Guest Information`})}),(0,d.jsxs)(`div`,{style:{background:`#fef3c7`,border:`1px solid #fde68a`,color:`#92400e`,borderRadius:`8px`,padding:`10px 14px`,fontSize:`12px`,marginBottom:`16px`,display:`flex`,alignItems:`center`,gap:`8px`},children:[(0,d.jsx)(`span`,{style:{fontSize:`14px`},children:`⏰`}),(0,d.jsxs)(`span`,{children:[(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:` stay period limits:`})}),` check-in starts at `,(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`2:00 p.m.`})}),`, check-out is strictly before `,(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`10:00 a.m.`})})]})]}),(0,d.jsxs)(`div`,{className:`bk-form-row`,children:[(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`First Name *`}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:k,onChange:e=>Le(e.target.value),required:!0})]}),(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`Last Name *`}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:A,onChange:e=>Re(e.target.value),required:!0})]})]}),(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`NIC / Passport Number *`}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:j,onChange:e=>ze(e.target.value),required:!0})]}),(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`Permanent Address *`}),(0,d.jsx)(`textarea`,{className:`bk-form-input`,rows:2,value:P,onChange:e=>Ke(e.target.value),required:!0,placeholder:`Enter your full permanent address`})]}),(0,d.jsxs)(`div`,{className:`bk-form-row`,children:[(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`Mobile Number *`}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:M,onChange:e=>Be(e.target.value),required:!0})]}),(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`Email Address *`}),(0,d.jsx)(`input`,{type:`email`,className:`bk-form-input`,value:N,onChange:e=>Ve(e.target.value),required:!0})]})]}),(0,d.jsxs)(`div`,{className:`bk-form-row`,style:{gridTemplateColumns:`1.2fr 1fr`,alignItems:`center`},children:[(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`Occupation *`}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:F,onChange:e=>qe(e.target.value),required:!0,placeholder:`e.g. Government Executive`})]}),(0,d.jsxs)(`div`,{className:`bk-form-group`,style:{display:`flex`,alignItems:`center`,marginTop:`1.25rem`},children:[(0,d.jsx)(`input`,{type:`checkbox`,id:`isCmaEmpCheckbox`,checked:L,onChange:e=>Ye(e.target.checked),style:{width:`18px`,height:`18px`,marginRight:`8px`,cursor:`pointer`}}),(0,d.jsx)(`label`,{htmlFor:`isCmaEmpCheckbox`,style:{fontSize:`13px`,fontWeight:600,color:`#374151`,cursor:`pointer`},children:`Employed at Ministry / CMA?`})]})]}),(0,d.jsxs)(`div`,{style:{background:`#fafafa`,border:`1px dashed var(--mid-gray)`,borderRadius:`10px`,padding:`14px`,marginBottom:`16px`},children:[(0,d.jsx)(`label`,{className:`bk-form-label`,style:{margin:0,fontWeight:700,fontSize:`13px`},children:`Government Institution Employee? (Optional)`}),(0,d.jsx)(`span`,{style:{fontSize:`11px`,color:`#64748b`,display:`block`,marginBottom:`8px`,lineHeight:1.4},children:(0,d.jsx)(l,{children:`If employed in a government institution, please attach an official letter confirming employment.`})}),n?(0,d.jsx)(`input`,{type:`file`,accept:`.pdf,image/*`,onChange:wt,style:{display:`block`,fontSize:`12px`,width:`100%`}}):(0,d.jsx)(`div`,{style:{fontSize:`11.5px`,color:`#64748b`},children:`Citizen sign-in is required only when attaching an official letter. You can submit a normal guest request without one.`}),Ze&&(0,d.jsx)(`div`,{style:{fontSize:`11px`,color:`var(--crimson)`,marginTop:`4px`,fontWeight:600},children:`Uploading official letter...`}),I&&(0,d.jsx)(`div`,{style:{fontSize:`11px`,color:`#16a34a`,marginTop:`4px`,fontWeight:600},children:`✓ Official letter uploaded successfully.`})]}),f===`employee`&&(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`CMA Employee ID *`}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`e.g. CMA-STF-889`,value:He,onChange:e=>Ue(e.target.value),required:!0}),(0,d.jsx)(`div`,{className:`bk-form-hint`,children:`Please enter your official employee credentials.`})]}),(0,d.jsxs)(`div`,{className:`bk-form-row`,children:[(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`No. of Adults *`}),(0,d.jsxs)(`select`,{className:`bk-form-select`,value:Ee,onChange:e=>De(e.target.value),children:[(0,d.jsx)(`option`,{value:1,children:`1`}),(0,d.jsx)(`option`,{value:2,children:`2`}),(0,d.jsx)(`option`,{value:3,children:`3`}),(0,d.jsx)(`option`,{value:4,children:`4`})]})]}),(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`No. of Children`}),(0,d.jsxs)(`select`,{className:`bk-form-select`,value:Oe,onChange:e=>ke(e.target.value),children:[(0,d.jsx)(`option`,{value:0,children:`0`}),(0,d.jsx)(`option`,{value:1,children:`1`}),(0,d.jsx)(`option`,{value:2,children:`2`}),(0,d.jsx)(`option`,{value:3,children:`3`})]})]})]}),(0,d.jsxs)(`div`,{style:{border:`1.5px solid var(--mid-gray)`,borderRadius:`10px`,padding:`16px`,marginBottom:`16px`,background:`#fff`},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,marginBottom:`12px`,flexWrap:`wrap`,gap:`8px`},children:[(0,d.jsxs)(`label`,{className:`bk-form-label`,style:{margin:0,fontWeight:700,fontSize:`13px`},children:[`Accompanying Family Members (`,R,`)`]}),(0,d.jsx)(`button`,{type:`button`,onClick:Tt,style:{padding:`4px 8px`,fontSize:`11px`,background:`var(--light-gray)`,border:`1px solid var(--mid-gray)`,borderRadius:`6px`,cursor:`pointer`,fontWeight:600},children:`+ Add Accompanying Member`})]}),z.length===0?(0,d.jsx)(`div`,{style:{fontSize:`12px`,color:`#64748b`,padding:`10px`,textAlign:`center`,background:`var(--off-white)`,borderRadius:`6px`},children:`No family members registered. Accompanying members can be added above.`}):(0,d.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`10px`},children:z.map((e,t)=>(0,d.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr auto`,gap:`8px`,alignItems:`center`},children:[(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`Family Member Name`,value:e.name,onChange:e=>Dt(t,`name`,e.target.value),style:{padding:`6px 8px`,fontSize:`12px`},required:!0}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`NIC No. / Passport`,value:e.nic,onChange:e=>Dt(t,`nic`,e.target.value),style:{padding:`6px 8px`,fontSize:`12px`},required:!0}),(0,d.jsx)(`button`,{type:`button`,onClick:()=>Et(t),style:{background:`#fee2e2`,border:`none`,borderRadius:`6px`,color:`#dc2626`,width:`28px`,height:`28px`,display:`flex`,alignItems:`center`,justifyContent:`center`,cursor:`pointer`,fontWeight:`bold`},children:`✕`})]},t))})]}),(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`Special Requests (Optional)`}),(0,d.jsx)(`textarea`,{className:`bk-form-input`,rows:2,value:We,onChange:e=>Ge(e.target.value),placeholder:`Late check-in, dietary, ground floor...`})]}),(0,d.jsx)(`div`,{className:`bk-btn-row`,children:(0,d.jsxs)(`button`,{className:`bk-btn-next`,type:`button`,disabled:!k||!A||!j||!M||!N||!P||!F||f===`employee`&&!He||T,onClick:At,children:[T?(0,d.jsx)(de,{size:16,style:{animation:`spin 1s linear infinite`,marginRight:`6px`}}):null,`Proceed to Book`]})})]}),C===2&&(0,d.jsxs)(`div`,{className:`bk-form-section active`,children:[(0,d.jsx)(`h4`,{style:{margin:`0 0 16px`,fontWeight:700},children:(0,d.jsx)(l,{children:`Review Details`})}),(0,d.jsxs)(`div`,{style:{background:`#f9f9f9`,borderRadius:`12px`,border:`1px solid #eee`,padding:`16px`,display:`flex`,flexDirection:`column`,gap:`8px`,marginBottom:`18px`},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Guest Name`})}),(0,d.jsxs)(`strong`,{style:{color:`var(--text-dark)`},children:[k,` `,A]})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`NIC Number`})}),(0,d.jsx)(`strong`,{children:j})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Contact Details`})}),(0,d.jsxs)(`strong`,{children:[M,` | `,N]})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Permanent Address`})}),(0,d.jsx)(`strong`,{style:{maxWidth:`240px`,textAlign:`right`,whiteSpace:`pre-wrap`},children:P})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Occupation`})}),(0,d.jsx)(`strong`,{children:F})]}),L&&(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Ministry / CMA Staff`})}),(0,d.jsx)(`strong`,{style:{color:`#16a34a`},children:(0,d.jsx)(l,{children:`Yes`})})]}),I&&(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Official Gov Letter`})}),(0,d.jsx)(`strong`,{style:{color:`#16a34a`},children:(0,d.jsx)(l,{children:`Attached`})})]}),z.length>0&&(0,d.jsxs)(`div`,{style:{borderTop:`1px solid #eee`,paddingTop:`8px`,fontSize:`12.5px`},children:[(0,d.jsxs)(`div`,{style:{fontWeight:600,color:`var(--text-muted)`,marginBottom:`4px`},children:[`Accompanying Members (`,R,`):`]}),(0,d.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`4px`,background:`var(--off-white)`,padding:`8px`,borderRadius:`6px`},children:z.map((e,t)=>(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,d.jsxs)(`span`,{children:[`• `,e.name]}),(0,d.jsxs)(`span`,{style:{color:`var(--text-muted)`},children:[`NIC: `,e.nic]})]},t))})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`,borderTop:`1px solid #eee`,paddingTop:`8px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Room(s) Selection`})}),(0,d.jsx)(`strong`,{style:{color:`var(--crimson)`},children:v.map(e=>e.name).join(`, `)})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Check-In`})}),(0,d.jsx)(`strong`,{children:$(p)})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Check-Out`})}),(0,d.jsx)(`strong`,{children:$(h)})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Nights`})}),(0,d.jsxs)(`strong`,{children:[X,` night`,X>1?`s`:``]})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`,borderTop:`1px solid #eee`,paddingTop:`8px`},children:[(0,d.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,d.jsx)(l,{children:`Total Amount`})}),(0,d.jsxs)(`strong`,{style:{fontSize:`16px`,color:`var(--crimson)`},children:[`Rs. `,Q().toLocaleString()]})]})]}),(0,d.jsxs)(`div`,{className:`bk-btn-row`,children:[(0,d.jsx)(`button`,{className:`bk-btn-back`,type:`button`,onClick:()=>w(1),children:`Back`}),(0,d.jsx)(`button`,{className:`bk-btn-next`,type:`button`,onClick:()=>w(3),children:`Proceed to Payment →`})]})]}),C===3&&(0,d.jsxs)(`div`,{className:`bk-form-section active`,children:[(0,d.jsx)(`h4`,{style:{margin:`0 0 16px`,fontWeight:700},children:(0,d.jsx)(l,{children:`Secure Payment Simulation`})}),(0,d.jsxs)(`div`,{className:`pay-methods`,children:[(0,d.jsxs)(`div`,{className:`pay-method${q===`card`?` active`:``}`,onClick:()=>J(`card`),children:[(0,d.jsx)(`span`,{className:`pay-method-icon`,children:`💳`}),(0,d.jsx)(`div`,{className:`pay-method-label`,children:`Credit/Debit`})]}),(0,d.jsxs)(`div`,{className:`pay-method${q===`bank`?` active`:``}`,onClick:()=>J(`bank`),children:[(0,d.jsx)(`span`,{className:`pay-method-icon`,children:`🏦`}),(0,d.jsx)(`div`,{className:`pay-method-label`,children:`Bank Transfer`})]}),(0,d.jsxs)(`div`,{className:`pay-method${q===`wallet`?` active`:``}`,onClick:()=>J(`wallet`),children:[(0,d.jsx)(`span`,{className:`pay-method-icon`,children:`📱`}),(0,d.jsx)(`div`,{className:`pay-method-label`,children:`e-Wallet`})]})]}),q===`card`?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)(`div`,{className:`card-preview`,children:[(0,d.jsx)(`div`,{className:`card-chip`}),(0,d.jsx)(`div`,{className:`card-number`,children:at||`•••• •••• •••• ••••`}),(0,d.jsxs)(`div`,{className:`card-info-row`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{className:`card-holder`,children:`Card Holder`}),(0,d.jsx)(`div`,{style:{fontSize:`13px`,fontWeight:700,color:`#fff`,textTransform:`uppercase`},children:rt||`YOUR NAME`})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{className:`card-expiry`,children:`Expires`}),(0,d.jsx)(`div`,{style:{fontSize:`13px`,fontWeight:700,color:`#fff`},children:st||`MM/YY`})]})]})]}),(0,d.jsxs)(`div`,{className:`pay-card-fields`,children:[(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`Cardholder Name *`}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`Kamal Perera`,value:rt,onChange:e=>it(e.target.value),required:!0})]}),(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`Card Number *`}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`4111 2222 3333 4444`,value:at,onChange:Mt,required:!0})]}),(0,d.jsxs)(`div`,{className:`pay-card-row`,children:[(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`Expiry Date *`}),(0,d.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`MM/YY`,value:st,onChange:Nt,required:!0})]}),(0,d.jsxs)(`div`,{className:`bk-form-group`,children:[(0,d.jsx)(`label`,{className:`bk-form-label`,children:`CVV *`}),(0,d.jsx)(`input`,{type:`password`,placeholder:`•••`,className:`bk-form-input`,value:lt,onChange:e=>ut(e.target.value.substring(0,3)),required:!0})]})]})]})]}):(0,d.jsx)(`div`,{style:{padding:`24px`,background:`#f9f9f9`,borderRadius:`12px`,border:`1px solid #eee`,fontSize:`13px`,color:`var(--text-muted)`,lineHeight:1.6,marginBottom:`16px`},children:`ℹ Selected payment method is in simulation mode. Standard demo checks require completing checkout via Credit/Debit card form and inputting the mock OTP verification code.`}),(0,d.jsxs)(`div`,{style:{background:`#f0fdf4`,border:`1px solid #bbf7d0`,borderRadius:`8px`,padding:`12px`,fontSize:`12.5px`,color:`#15803d`,display:`flex`,gap:`8px`,alignItems:`center`,marginBottom:`18px`},children:[(0,d.jsx)(le,{size:14}),(0,d.jsxs)(`span`,{children:[`SSL encrypted transaction. Booking amount: `,(0,d.jsxs)(`strong`,{children:[`Rs. `,Q().toLocaleString()]})]})]}),(0,d.jsxs)(`div`,{className:`bk-btn-row`,children:[(0,d.jsx)(`button`,{className:`bk-btn-back`,type:`button`,onClick:()=>w(2),children:`Back`}),(0,d.jsx)(`button`,{className:`bk-btn-next`,type:`button`,disabled:q===`card`&&(!rt||!at||!st||!lt),onClick:()=>w(4),children:`Pay & Get OTP →`})]})]}),C===4&&(0,d.jsxs)(`div`,{className:`bk-form-section active`,children:[(0,d.jsxs)(`div`,{className:`otp-container`,children:[(0,d.jsx)(`div`,{className:`otp-icon`,children:`📲`}),(0,d.jsx)(`h3`,{className:`otp-heading`,style:{margin:0},children:(0,d.jsx)(l,{children:`OTP Verification`})}),(0,d.jsxs)(`p`,{className:`otp-sub`,style:{marginTop:`8px`},children:[`A 6-digit One-Time Password has been sent to your simulated mobile number `,(0,d.jsx)(`strong`,{children:M||`+94 77 *** ****`}),`. Please enter it below to confirm your payment.`]}),(0,d.jsx)(`div`,{className:`otp-input-row`,style:{display:`flex`,gap:`8px`,justifyContent:`center`,margin:`20px 0`},children:dt.map((e,t)=>(0,d.jsx)(`input`,{ref:e=>ht.current[t]=e,type:`text`,maxLength:1,className:`otp-digit`,value:e,onChange:e=>Ot(e,t),onKeyDown:e=>kt(e,t),style:{width:`45px`,height:`52px`,borderRadius:`8px`,border:`2px solid #ddd`,textAlign:`center`,fontSize:`20px`,fontWeight:700}},t))}),(0,d.jsxs)(`div`,{className:`otp-resend`,style:{fontSize:`13px`},children:[`Didn't receive the OTP? `,(0,d.jsx)(`button`,{style:{color:`var(--crimson)`,fontWeight:700,border:`none`,background:`none`},onClick:()=>mt(60),children:`Resend`}),` `,pt>0&&(0,d.jsxs)(`span`,{className:`otp-timer`,children:[`(`,pt,`s)`]})]}),(0,d.jsxs)(`div`,{style:{background:`rgba(139,26,26,.06)`,borderRadius:`10px`,padding:`12px 16px`,fontSize:`12.5px`,color:`var(--text-body)`,margin:`20px 0 0`,textAlign:`left`,border:`1px dashed var(--crimson)`},children:[(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`Demo Simulation:`})}),` Enter `,(0,d.jsx)(`strong`,{style:{color:`var(--crimson)`},children:(0,d.jsx)(l,{children:`1 2 3 4 5 6`})}),` to verify transaction successfully.`]})]}),(0,d.jsxs)(`div`,{className:`bk-btn-row`,style:{marginTop:`24px`},children:[(0,d.jsx)(`button`,{className:`bk-btn-back`,type:`button`,onClick:()=>w(3),children:`Back`}),(0,d.jsxs)(`button`,{className:`bk-btn-next`,type:`button`,disabled:T,onClick:Pt,children:[T?(0,d.jsx)(de,{size:16,style:{animation:`spin 1s linear infinite`,marginRight:`6px`}}):null,`Confirm Booking & Pay`]})]})]}),C===5&&D&&(0,d.jsx)(`div`,{className:`bk-form-section active`,children:(0,d.jsxs)(`div`,{className:`bk-success`,children:[(0,d.jsx)(`div`,{className:`bk-success-icon`,style:{fontSize:`3.5rem`},children:D.booking_status===`Confirmed`?`✅`:`⏳`}),(0,d.jsx)(`h3`,{className:`bk-success-title`,style:{margin:`10px 0 0`},children:D.booking_status===`Confirmed`?`Booking Successful!`:`Booking Request Submitted`}),(0,d.jsx)(`p`,{className:`bk-success-sub`,style:{marginTop:`8px`,fontWeight:`600`,color:D.booking_status===`Confirmed`?`#15803d`:`#b45309`},children:D.booking_status===`Confirmed`?`Your reservation has been approved. The selected dates are now secured.`:`Payment is pending and your request is awaiting administrator approval. No payment has been collected online.`}),(0,d.jsxs)(`div`,{className:`bk-ref-box`,children:[(0,d.jsx)(`div`,{className:`bk-ref-label`,children:`Booking Reference Number`}),(0,d.jsx)(`div`,{className:`bk-ref-num`,children:D.allReferences?D.allReferences:D.reference_no})]}),(0,d.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:`10px`,margin:`14px 0`},children:[(0,d.jsxs)(`div`,{style:{padding:`10px`,borderRadius:`8px`,background:`#fffbeb`,border:`1px solid #fde68a`,color:`#92400e`,fontSize:`12px`},children:[`Payment: `,(0,d.jsx)(`strong`,{children:D.payment_status||`Pending`})]}),(0,d.jsxs)(`div`,{style:{padding:`10px`,borderRadius:`8px`,background:`#fffbeb`,border:`1px solid #fde68a`,color:`#92400e`,fontSize:`12px`},children:[`Approval: `,(0,d.jsx)(`strong`,{children:D.booking_status||`Pending`})]})]}),(0,d.jsxs)(`div`,{className:`bk-success-details`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`Room Type:`})}),(0,d.jsx)(`span`,{children:D.unit_number})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`Check-In Date:`})}),(0,d.jsx)(`span`,{children:D.check_in})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`Check-Out Date:`})}),(0,d.jsx)(`span`,{children:D.check_out})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`strong`,{children:(0,d.jsx)(l,{children:`Total Amount:`})}),(0,d.jsxs)(`span`,{style:{color:`var(--success)`,fontWeight:700},children:[`Rs. `,Number(D.amount).toLocaleString()]})]})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,marginTop:`24px`,justifyContent:`center`},children:[(0,d.jsx)(`button`,{className:`btn btn-outline`,style:{borderRadius:`8px`,padding:`10px 20px`,fontSize:`13px`,marginRight:`8px`},onClick:jt,disabled:G,children:`Refresh Status`}),(0,d.jsx)(`button`,{className:`btn btn-primary`,style:{borderRadius:`8px`,padding:`10px 20px`,fontSize:`13px`},onClick:()=>{S(!1),y([]),m(null),g(null)},children:`Close`})]})]})})]})]})}),(0,d.jsx)(`style`,{children:`
        /* CUSTOM OVERRIDES FOR KATARAGAMA CIRCUIT BUNGALOW VIEW */
        .bk-hero {
          position: relative;
          min-height: 440px;
          overflow: hidden;
          background: #000;
          display: flex;
          align-items: center;
        }
        .bk-hero-bg {
          position: absolute;
          inset: 0;
          background-image: url('https://images.unsplash.com/photo-1586348943529-beaae6c28db9?w=1400&auto=format&fit=crop&q=70');
          background-size: cover;
          background-position: center;
          opacity: 0.55;
        }
        .bk-hero-overlay {
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, rgba(26,20,16,.92) 0%, rgba(139,26,26,.55) 60%, rgba(26,20,16,.6) 100%);
        }
        .bk-hero-inner {
          position: relative;
          z-index: 2;
          max-width: var(--container-max);
          margin: 0 auto;
          padding: 72px 24px;
          display: grid;
          grid-template-columns: 1.2fr 1fr;
          gap: 48px;
          align-items: center;
          width: 100%;
        }
        .bk-hero-eyebrow {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: .14em;
          text-transform: uppercase;
          color: var(--gold-light);
          background: rgba(201,162,39,0.15);
          border: 1px solid rgba(201,162,39,0.3);
          border-radius: 100px;
          padding: 6px 14px;
          display: inline-block;
        }
        .bk-hero-title {
          font-size: clamp(28px, 4vw, 48px);
          font-weight: 800;
          color: #fff;
          line-height: 1.15;
          margin-bottom: 14px;
        }
        .bk-hero-title em {
          color: var(--gold-light);
          font-style: italic;
        }
        .bk-hero-desc {
          font-size: 14.5px;
          color: rgba(255, 255, 255, 0.8);
          line-height: 1.7;
          margin-bottom: 28px;
          max-width: 520px;
        }
        .bk-stats-row {
          display: flex;
          gap: 28px;
          flex-wrap: wrap;
        }
        .bk-stat {
          text-align: left;
        }
        .bk-stat-num {
          font-size: 24px;
          font-weight: 800;
          color: var(--gold-light);
        }
        .bk-stat-lbl {
          font-size: 11px;
          color: rgba(255,255,255,0.6);
          font-weight: 600;
          letter-spacing: .04em;
          display: block;
          margin-top: 2px;
        }
        .bk-hero-gallery {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }
        .bk-gallery-img {
          border-radius: 12px;
          overflow: hidden;
          background: rgba(255,255,255,.05);
          border: 1px solid rgba(201,162,39,.2);
        }
        .bk-gallery-img img {
          width: 100%;
          height: 274px;
          object-fit: cover;
          display: block;
          transition: transform .4s;
        }
        .bk-gallery-img:hover img {
          transform: scale(1.05);
        }

        /* USER ROLE SELECTOR */
        .role-selector-sec {
          background: #f7f5f2;
          border-bottom: 1px solid var(--mid-gray);
        }
        .role-selector-inner {
          max-width: var(--container-max);
          margin: 0 auto;
          padding: 20px 24px;
        }
        .role-row {
          display: flex;
          align-items: center;
          gap: 12px;
          flex-wrap: wrap;
        }
        .role-label {
          font-size: 12.5px;
          font-weight: 700;
          color: var(--text-dark);
          letter-spacing: .06em;
          text-transform: uppercase;
        }
        .role-btn {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 10px 20px;
          border-radius: 100px;
          border: 2px solid var(--mid-gray);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          background: #fff;
          color: var(--text-body);
          transition: all .25s;
        }
        .role-btn:hover {
          border-color: var(--crimson);
          color: var(--crimson);
        }
        .role-btn.active {
          background: var(--crimson);
          border-color: var(--crimson);
          color: #fff;
          box-shadow: var(--shadow-crimson);
        }
        .role-badge {
          font-size: 10px;
          padding: 2px 8px;
          border-radius: 100px;
          font-weight: 700;
          letter-spacing: .05em;
        }
        .role-btn.active .role-badge {
          background: rgba(255,255,255,.2);
          color: #fff;
        }
        .role-btn .role-badge {
          background: rgba(139,0,0,.08);
          color: var(--crimson);
        }
        #roleEmployee.active {
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          border-color: var(--crimson);
        }

        /* MAIN BOOKING LAYOUT */
        .booking-layout {
          display: grid;
          grid-template-columns: 1fr 380px;
          gap: 36px;
          align-items: start;
        }

        /* AVAILABILITY CALENDAR */
        .avail-card {
          background: #fff;
          border-radius: var(--radius-md);
          border: 1px solid var(--mid-gray);
          overflow: hidden;
          box-shadow: var(--shadow-sm);
        }
        .avail-head {
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          padding: 22px 24px;
          color: #fff;
        }
        .avail-head-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 6px;
        }
        .avail-nav {
          display: flex;
          gap: 6px;
        }
        .avail-nav-btn {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          border: 1.5px solid rgba(255,255,255,.3);
          background: rgba(255,255,255,.1);
          color: #fff;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background .2s;
        }
        .avail-nav-btn:hover {
          background: rgba(255,255,255,.25);
        }
        .avail-month-label {
          font-size: 13px;
          color: rgba(255,255,255,.7);
          letter-spacing: .04em;
          text-transform: uppercase;
          font-weight: 700;
        }
        .avail-legend {
          display: flex;
          gap: 16px;
          margin-top: 12px;
          flex-wrap: wrap;
        }
        .avail-dot {
          width: 10px;
          height: 10px;
          border-radius: 50%;
          flex-shrink: 0;
        }
        .avail-legend-item {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: rgba(255,255,255,.8);
        }
        .cal-grid {
          padding: 20px 24px;
        }
        .cal-dow {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 4px;
          margin-bottom: 8px;
        }
        .cal-dow span {
          text-align: center;
          font-size: 11px;
          font-weight: 700;
          color: var(--text-muted);
          letter-spacing: .06em;
          padding: 6px 0;
          text-transform: uppercase;
        }
        .cal-days {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 4px;
        }
        .cal-day {
          aspect-ratio: 1.2;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          position: relative;
          transition: all .2s;
          border: 1.5px solid transparent;
        }
        .cal-day.empty {
          cursor: default;
        }
        .cal-day.available {
          background: rgba(26,127,90,.08);
          color: var(--success);
          border-color: rgba(26,127,90,.2);
        }
        .cal-day.available:hover {
          background: rgba(26,127,90,.18);
          transform: scale(1.08);
        }
        .cal-day.partial {
          background: rgba(217,119,6,.08);
          color: var(--warning);
          border-color: rgba(217,119,6,.2);
        }
        .cal-day.partial:hover {
          background: rgba(217,119,6,.18);
          transform: scale(1.08);
        }
        .cal-day.booked {
          background: rgba(139,0,0,.06);
          color: var(--text-muted);
          cursor: not-allowed;
          border-color: rgba(139,0,0,.1);
        }
        .cal-day.today {
          box-shadow: 0 0 0 2px var(--gold);
        }
        .cal-day.selected {
          background: var(--crimson)!important;
          color: #fff!important;
          border-color: var(--crimson)!important;
          box-shadow: var(--shadow-crimson);
        }
        .cal-day.checkout-day {
          background: var(--gold)!important;
          color: #fff!important;
          border-color: var(--gold)!important;
        }
        .cal-day.in-range {
          background: rgba(139,0,0,.08);
          border-color: transparent;
        }
        .cal-day.user-blocked {
          cursor: not-allowed;
          opacity: .55;
          filter: grayscale(.4);
        }
        .cal-day.user-blocked:hover {
          transform: none!important;
          background: inherit!important;
        }
        .cal-user-notice {
          margin: 0 24px 18px;
          padding: 10px 14px;
          background: rgba(139,0,0,.04);
          border: 1px solid rgba(139,0,0,.15);
          border-radius: 8px;
          font-size: 12px;
          color: var(--crimson);
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .avail-detail-row {
          padding: 0 24px 20px;
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }
        .avail-room-chip {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 600;
          border: 1.5px solid #eee;
        }
        .chip-green { background: rgba(26,127,90,.04); color: var(--success); border-color: rgba(26,127,90,.15); }
        .chip-orange { background: rgba(217,119,6,.04); color: var(--warning); border-color: rgba(217,119,6,.15); }
        .chip-red { background: rgba(139,0,0,.04); color: var(--crimson); border-color: rgba(139,0,0,.1); }

        /* ROOM LISTINGS */
        .rooms-sec {
          margin-top: 32px;
        }
        .rooms-sec-head h3 {
          font-size: 20px;
          font-weight: 800;
          color: var(--text-dark);
          margin-bottom: 16px;
        }
        .rooms-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 18px;
        }
        .room-card {
          background: #fff;
          border-radius: var(--radius-md);
          border: 1.5px solid var(--mid-gray);
          overflow: hidden;
          transition: var(--transition);
          cursor: pointer;
          display: flex;
          flex-direction: column;
        }
        .room-card:hover {
          box-shadow: var(--shadow-md);
          border-color: rgba(139,0,0,.2);
          transform: translateY(-3px);
        }
        .room-card.selected-room {
          border-color: var(--crimson);
          box-shadow: 0 0 0 3px rgba(139,0,0,.12);
        }
        .room-img {
          width: 100%;
          height: 140px;
          object-fit: cover;
        }
        .room-img-placeholder {
          width: 100%;
          height: 140px;
          background: linear-gradient(135deg, var(--light-gray), var(--off-white));
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .room-body {
          padding: 16px;
          flex: 1;
          display: flex;
          flex-direction: column;
        }
        .room-name {
          font-size: 15px;
          font-weight: 700;
          color: var(--text-dark);
        }
        .room-meta {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          margin-bottom: 12px;
        }
        .room-meta-item {
          display: flex;
          align-items: center;
          gap: 4px;
          font-size: 11px;
          color: var(--text-muted);
          background: var(--off-white);
          padding: 3px 8px;
          border-radius: 4px;
        }
        .room-price-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-top: auto;
        }
        .room-price {
          font-size: 18px;
          font-weight: 800;
          color: var(--crimson);
        }
        .room-select-btn {
          width: 100%;
          margin-top: 12px;
          padding: 8px;
          border-radius: 6px;
          border: 1.5px solid var(--crimson);
          background: #fff;
          color: var(--crimson);
          font-size: 12px;
          font-weight: 700;
          transition: all 0.2s;
        }
        .room-select-btn:hover, .room-card.selected-room .room-select-btn {
          background: var(--crimson);
          color: #fff;
        }

        /* BOOKING SIDEBAR */
        .booking-sidebar {
          display: flex;
          flex-direction: column;
          gap: 20px;
          position: sticky;
          top: 120px;
        }
        .bk-summary-card {
          background: #fff;
          border-radius: var(--radius-md);
          border: 1px solid var(--mid-gray);
          overflow: hidden;
          box-shadow: var(--shadow-sm);
        }
        .bk-sum-head {
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          padding: 18px 22px;
          color: #fff;
        }
        .bk-sum-body {
          padding: 20px 22px;
        }
        .bk-sum-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 10px 0;
          border-bottom: 1px solid var(--light-gray);
          font-size: 13px;
        }
        .bk-sum-row:last-child {
          border-bottom: none;
        }
        .bk-sum-label {
          color: var(--text-muted);
          font-weight: 500;
        }
        .bk-sum-value {
          color: var(--text-dark);
          font-weight: 600;
          text-align: right;
          max-width: 60%;
        }
        .bk-sum-total {
          background: var(--off-white);
          border-radius: 8px;
          padding: 12px 16px;
          margin-top: 12px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .bk-sum-total-label {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-body);
        }
        .bk-sum-total-val {
          font-size: 20px;
          font-weight: 800;
          color: var(--crimson);
        }
        .bk-proceed-btn {
          width: 100%;
          margin-top: 16px;
          padding: 12px;
          border-radius: 8px;
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          color: #fff;
          border: none;
          font-size: 14px;
          font-weight: 700;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          transition: var(--transition);
        }
        .bk-proceed-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: var(--shadow-crimson);
        }
        .bk-proceed-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .bk-trust-items {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .bk-trust-item {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 11.5px;
          color: var(--text-muted);
        }

        /* FACILITIES */
        .facilities-sec {
          background: var(--off-white);
        }
        .facilities-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 20px;
        }
        .facility-card {
          background: #fff;
          border-radius: var(--radius-md);
          padding: 24px 20px;
          text-align: center;
          border: 1px solid var(--mid-gray);
          transition: var(--transition);
        }
        .facility-card:hover {
          box-shadow: var(--shadow-md);
          border-color: rgba(139,0,0,.1);
          transform: translateY(-4px);
        }
        .facility-icon {
          font-size: 2.2rem;
          margin-bottom: 12px;
          display: block;
        }
        .facility-name {
          font-size: 14.5px;
          font-weight: 700;
          color: var(--text-dark);
          margin-bottom: 6px;
        }
        .facility-desc {
          font-size: 12px;
          color: var(--text-muted);
          line-height: 1.5;
        }

        /* BOOKING FORM MODAL */
        .bk-modal-overlay {
          display: none;
          position: fixed;
          inset: 0;
          z-index: 3500;
          background: rgba(0,0,0,.6);
          backdrop-filter: blur(4px);
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .bk-modal-overlay.open {
          display: flex;
        }
        .bk-modal {
          background: #fff;
          border-radius: 16px;
          max-width: 580px;
          width: 100%;
          max-height: 90vh;
          overflow-y: auto;
          box-shadow: var(--shadow-xl);
          display: flex;
          flex-direction: column;
        }
        .bk-modal-head {
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          padding: 20px 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          color: #fff;
        }
        .bk-modal-title {
          font-size: 16.5px;
          font-weight: 700;
        }
        .bk-modal-close {
          background: rgba(255,255,255,.15);
          border: none;
          color: #fff;
          width: 28px;
          height: 28px;
          border-radius: 50%;
          cursor: pointer;
          font-size: 13px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .bk-modal-body {
          padding: 24px;
        }
        .bk-steps {
          display: flex;
          margin-bottom: 24px;
          position: relative;
        }
        .bk-steps::before {
          content: '';
          position: absolute;
          top: 15px;
          left: 10%;
          right: 10%;
          height: 2px;
          background: var(--light-gray);
          z-index: 0;
        }
        .bk-step {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          position: relative;
          z-index: 1;
        }
        .bk-step-circle {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          border: 2px solid var(--mid-gray);
          background: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 700;
          color: var(--text-muted);
          transition: all 0.3s;
        }
        .bk-step.active .bk-step-circle {
          background: var(--crimson);
          border-color: var(--crimson);
          color: #fff;
        }
        .bk-step.done .bk-step-circle {
          background: var(--success);
          border-color: var(--success);
          color: #fff;
        }
        .bk-step-label {
          font-size: 10px;
          font-weight: 600;
          color: var(--text-muted);
          text-align: center;
        }
        .bk-step.active .bk-step-label { color: var(--crimson); }
        .bk-step.done .bk-step-label { color: var(--success); }

        .bk-form-group {
          margin-bottom: 14px;
        }
        .bk-form-label {
          display: block;
          font-size: 11.5px;
          font-weight: 700;
          color: var(--text-dark);
          margin-bottom: 4px;
        }
        .bk-form-input, .bk-form-select {
          width: 100%;
          padding: 10px 12px;
          border: 1.5px solid var(--mid-gray);
          border-radius: 8px;
          font-size: 13px;
          color: var(--text-body);
          background: #fff;
          outline: none;
          box-sizing: border-box;
        }
        .bk-form-input:focus, .bk-form-select:focus {
          border-color: var(--crimson);
        }
        .bk-form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
        }
        .bk-form-hint {
          font-size: 10.5px;
          color: var(--text-muted);
          margin-top: 2px;
        }
        .bk-btn-row {
          display: flex;
          gap: 12px;
          margin-top: 20px;
        }
        .bk-btn-next, .bk-btn-back, .bk-btn-submit {
          padding: 11px 20px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          border: none;
          transition: all 0.2s;
        }
        .bk-btn-next {
          background: var(--crimson);
          color: #fff;
          flex: 1;
        }
        .bk-btn-next:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .bk-btn-back {
          background: var(--off-white);
          color: var(--text-body);
          border: 1.5px solid var(--mid-gray);
        }

        /* PAYMENT SECTION */
        .pay-methods {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
          margin-bottom: 16px;
        }
        .pay-method {
          padding: 10px;
          border-radius: 8px;
          border: 1.5px solid var(--mid-gray);
          cursor: pointer;
          text-align: center;
          transition: all 0.2s;
        }
        .pay-method:hover { border-color: var(--crimson); }
        .pay-method.active { border-color: var(--crimson); background: rgba(139,0,0,.03); }
        .pay-method-icon { font-size: 1.5rem; margin-bottom: 2px; display: block; }
        .pay-method-label { font-size: 11px; font-weight: 700; }

        .card-preview {
          background: linear-gradient(135deg, #1f2937, #111827);
          border-radius: 12px;
          padding: 18px;
          color: #fff;
          margin-bottom: 14px;
          position: relative;
          overflow: hidden;
          box-shadow: var(--shadow-md);
        }
        .card-preview::before {
          content: '';
          position: absolute;
          top: -20px;
          right: -20px;
          width: 100px;
          height: 100px;
          border-radius: 50%;
          background: rgba(255,255,255,0.03);
        }
        .card-chip {
          width: 32px;
          height: 24px;
          background: linear-gradient(135deg, var(--gold), var(--gold-light));
          border-radius: 4px;
          margin-bottom: 12px;
        }
        .card-number {
          font-size: 15px;
          letter-spacing: 0.18em;
          font-weight: 700;
          margin-bottom: 12px;
          font-family: monospace;
        }
        .card-info-row {
          display: flex;
          justify-content: space-between;
        }
        .card-holder, .card-expiry {
          font-size: 9px;
          color: rgba(255,255,255,.5);
          text-transform: uppercase;
          letter-spacing: .06em;
        }
        .pay-card-fields {
          background: var(--off-white);
          border-radius: 10px;
          padding: 14px;
          margin-bottom: 14px;
          border: 1px solid var(--mid-gray);
        }
        .pay-card-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }

        /* SUCCESS INVOICE */
        .bk-success {
          text-align: center;
          padding: 10px 0;
        }
        .bk-success-icon {
          animation: scaleIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        @keyframes scaleIn { from{transform:scale(0.5);opacity:0;} to{transform:scale(1);opacity:1;} }
        .bk-ref-box {
          background: rgba(26,127,90,.03);
          border: 1.5px dashed rgba(26,127,90,.3);
          border-radius: 10px;
          padding: 14px 20px;
          margin: 18px 0;
        }
        .bk-ref-label {
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          color: var(--success);
          letter-spacing: 0.08em;
        }
        .bk-ref-num {
          font-size: 22px;
          font-weight: 800;
          color: var(--text-dark);
          letter-spacing: 0.05em;
        }
        .bk-success-details {
          background: var(--off-white);
          border-radius: 10px;
          padding: 12px 16px;
          text-align: left;
          border: 1px solid var(--mid-gray);
        }
        .bk-success-details div {
          display: flex;
          justify-content: space-between;
          padding: 6px 0;
          border-bottom: 1px solid var(--light-gray);
          font-size: 12.5px;
        }
        .bk-success-details div:last-child {
          border-bottom: none;
        }

        /* RESPONSIVE LAYOUT OVERRIDES */
        @media(max-width: 1024px) {
          .booking-layout { grid-template-columns: 1fr; }
          .bk-hero-inner { grid-template-columns: 1fr; gap: 24px; }
          .bk-hero-gallery { display: none; }
          .facilities-grid { grid-template-columns: 1fr 1fr; }
        }
        @media(max-width: 900px) {
          .bk-availability-grid { grid-template-columns: 1fr !important; gap: 20px !important; }
        }
        @media(max-width: 768px) {
          .rooms-grid { grid-template-columns: 1fr; }
          .facilities-grid { grid-template-columns: 1fr 1fr; }
          .booking-layout { gap: 20px; }
        }
        @media(max-width: 600px) {
          .bk-form-row { grid-template-columns: 1fr !important; gap: 12px !important; }
          .pay-methods { grid-template-columns: 1fr !important; }
        }
        @media(max-width: 640px) {
          .facilities-grid { grid-template-columns: 1fr; }
          .bk-date-row { flex-direction: column !important; gap: 12px !important; }
          .bk-guest-row { flex-direction: column !important; gap: 12px !important; }
          .bk-step-row { flex-direction: column !important; gap: 12px !important; }
          .bk-pay-row { flex-direction: column !important; gap: 10px !important; }
          .bk-confirm-actions { flex-direction: column !important; gap: 12px !important; }
          .bk-confirm-actions a, .bk-confirm-actions button { width: 100% !important; text-align: center !important; justify-content: center !important; }
          .bk-summary-grid { grid-template-columns: 1fr !important; }
          .bk-otp-row { gap: 8px !important; }
          .bk-modal-inner { padding: 24px 16px !important; border-radius: 16px !important; margin: 12px !important; }
        }
        @media(max-width: 480px) {
          .bk-hero { padding: 48px 16px 40px !important; }
          .bk-hero h1 { font-size: clamp(1.5rem, 6vw, 2.5rem) !important; }
          .bk-section-inner { padding: 20px 16px !important; }
          .bk-room-card { padding: 16px !important; }
          .bk-calendar-header { flex-direction: column !important; gap: 8px !important; align-items: flex-start !important; }
          .bk-amenity-tag { font-size: 11px !important; padding: 4px 8px !important; }
          .bk-dates-input-grid { grid-template-columns: 1fr !important; gap: 12px !important; }
        }
      `})]})}export{f as default};