import{n as e,s as t,t as n}from"./jsx-runtime-B7FaSiYN.js";import{$ as r,Q as i,Tt as a,V as o,W as ee,et as te,o as ne,r as re,s as ie,t as ae,xt as s,yt as oe}from"./index-BH0K_KMx.js";import{Kt as se,Ot as ce,Rr as le,Sn as ue,W as de,Wt as fe,cr as pe,en as me,f as he,in as c,m as ge,mi as _e,nt as l,oi as ve,t as ye,wi as be}from"./lucide-react-B1udUleT.js";import{t as u}from"./T-BuyWwWUw.js";var d=t(e(),1);ae(),ye(),ne(),s();var f=n(),xe={background:{image:`https://images.unsplash.com/photo-1586348943529-beaae6c28db9?w=1400&auto=format&fit=crop&q=70`,alt_text:`Kataragama natural landscape`},gallery_1:{image:`https://media-cdn.tripadvisor.com/media/photo-s/02/e0/70/a5/gem-river-edge-eco-home.jpg`,alt_text:`Kataragama bungalow surroundings`},gallery_2:{image:`https://images.unsplash.com/photo-1560185008-b033106af5c3?w=900&auto=format&fit=crop&q=75`,alt_text:`Bungalow living room`},gallery_3:{image:`https://st5.depositphotos.com/19085394/64942/i/450/depositphotos_649426038-stock-photo-kirivehara-kiri-vehera-shrine-kataragama.jpg`,alt_text:`Kataragama Kiri Vehera Temple`}};function Se(){let{t:e}=re(),{citizen:t,isCitizenLoggedIn:n}=ie(),[ne,ae]=(0,d.useState)([]),[s,ye]=(0,d.useState)(xe),[Se,Ce]=(0,d.useState)(!0),[p,we]=(0,d.useState)(`guest`),[m,Te]=(0,d.useState)(null),[h,Ee]=(0,d.useState)(null),[g,De]=(0,d.useState)(``),[Oe,ke]=(0,d.useState)(``),[_,v]=(0,d.useState)([]),Ae=e=>{_.some(t=>t.id===e.id)?v([]):v([e])},[y,je]=(0,d.useState)(2),[b,Me]=(0,d.useState)(0),[x,Ne]=(0,d.useState)(new Date),[S,Pe]=(0,d.useState)({}),[Fe,Ie]=(0,d.useState)(!1),[Le,C]=(0,d.useState)(!1),[w,T]=(0,d.useState)(1),[E,Re]=(0,d.useState)(!1),[ze,D]=(0,d.useState)(``),[O,k]=(0,d.useState)(null),[A,Be]=(0,d.useState)(``),[j,Ve]=(0,d.useState)(``),[M,He]=(0,d.useState)(``),[N,Ue]=(0,d.useState)(``),[P,We]=(0,d.useState)(``),[F,Ge]=(0,d.useState)(``),[Ke,qe]=(0,d.useState)(``),[I,Je]=(0,d.useState)(``),[L,Ye]=(0,d.useState)(``),[R,Xe]=(0,d.useState)(``),[z,Ze]=(0,d.useState)(!1),[B,Qe]=(0,d.useState)(0),[V,H]=(0,d.useState)([]),[$e,et]=(0,d.useState)(!1),[U,tt]=(0,d.useState)(()=>localStorage.getItem(`ktgb_reference`)||``),[W,nt]=(0,d.useState)(()=>localStorage.getItem(`ktgb_phone`)||``),[G,K]=(0,d.useState)(null),[q,rt]=(0,d.useState)(!1),[it,at]=(0,d.useState)(``),[J,ot]=(0,d.useState)(`card`),[st,ct]=(0,d.useState)(``),[lt,ut]=(0,d.useState)(``),[dt,ft]=(0,d.useState)(``),[pt,mt]=(0,d.useState)(``),[ht,gt]=(0,d.useState)([``,``,``,``,``,``]),[_t,vt]=(0,d.useState)(60),yt=(0,d.useRef)([]),bt=async()=>{Ie(!0);try{let e=await i();e.data&&e.data.status===`success`&&Pe(e.data.data)}catch(e){console.error(`Failed to fetch booking availability:`,e)}finally{Ie(!1)}},xt=async()=>{Ce(!0);try{ae((await te()).data?.data||[])}catch(e){console.error(`Failed to fetch rooms list:`,e)}finally{Ce(!1)}},St=async()=>{try{ye(((await r()).data?.data||[]).reduce((e,t)=>({...e,[t.slot]:t}),{}))}catch(e){console.error(`Failed to fetch bungalow hero images:`,e)}};(0,d.useEffect)(()=>{bt(),xt(),St()},[]),(0,d.useEffect)(()=>{if(t){let e=t.name.split(` `);Be(e[0]||``),Ve(e.slice(1).join(` `)||``),We(t.email||``),Ue(t.phone||``),He(t.nic||``)}},[t]);let Y=(()=>{if(!m||!h)return 0;let e=Math.abs(h.getTime()-m.getTime())/(1e3*60*60);return Math.max(1,Math.ceil(e/24))})(),X=e=>{if(!e)return 0;let t=e.emp_price===void 0?e.empPrice:e.emp_price;return p===`employee`?t:e.price},Z=()=>_.length===0||Y===0?0:_.reduce((e,t)=>e+X(t),0)*Y,Ct=e=>new Date(e.getFullYear(),e.getMonth()+1,0).getDate(),wt=e=>new Date(e.getFullYear(),e.getMonth(),1).getDay(),Tt=()=>{Ne(new Date(x.getFullYear(),x.getMonth()-1,1))},Et=()=>{Ne(new Date(x.getFullYear(),x.getMonth()+1,1))},Dt=(e,t,n)=>`${e}-${String(t+1).padStart(2,`0`)}-${String(n).padStart(2,`0`)}`,Q=e=>e?e.toLocaleDateString(`en-GB`,{day:`numeric`,month:`short`,year:`numeric`,hour:`2-digit`,minute:`2-digit`}):`Select date & time`,Ot=()=>{if(!m||!h)return!1;let e=new Date(m),t=new Date(h);for(e.toDateString()!==t.toDateString()&&t.setDate(t.getDate()-1);e<=t;){if(S[Dt(e.getFullYear(),e.getMonth(),e.getDate())]===`booked`)return!0;e.setDate(e.getDate()+1)}return!1},kt=()=>{if(Ot()){window.alert(`One or more selected dates are already booked. Please select another stay period.`);return}k(null),D(``),T(1),C(!0)},At=async e=>{let t=e.target.files[0];if(t){et(!0);try{Xe((await ee(t)).data.path),alert(`Official letter uploaded successfully!`)}catch(e){console.error(e),alert(`Failed to upload file. Please try again.`)}finally{et(!1)}}},jt=()=>{H([...V,{name:``,nic:``}]),Qe(e=>e+1)},Mt=e=>{let t=[...V];t.splice(e,1),H(t),Qe(e=>Math.max(0,e-1))},Nt=(e,t,n)=>{let r=[...V];r[e]={...r[e],[t]:n},H(r)},Pt=(e,t)=>{let n=e.target.value.replace(/\D/g,``).slice(-1),r=[...ht];r[t]=n,gt(r),n&&t<5&&yt.current[t+1]?.focus()},Ft=(e,t)=>{e.key===`Backspace`&&!ht[t]&&t>0&&yt.current[t-1]?.focus()},It=async()=>{Re(!0),D(``);try{let e=_.map(e=>a({guest_name:`${A} ${j}`.trim(),email:P,phone:N,nic:M,employee_id:p===`employee`?F:null,unit_number:e.name,check_in:g.replace(`T`,` `),check_out:Oe.replace(`T`,` `),adults:Number(y),children:Number(b),amount:X(e)*Y,notes:Ke,permanent_address:I,occupation:L,gov_letter:R||null,is_cma_employee:!!z,family_count:Number(B),family_members:V})),t=await Promise.all(e),n=t[0];if(n.data&&n.data.status===`success`){let e=t.map(e=>e.data.data),r=e.map(e=>e.reference_no);k({...n.data.data,unit_number:_.map(e=>e.name).join(`, `),amount:Z(),allReferences:r.join(`, `),allBookings:e}),localStorage.setItem(`ktgb_reference`,r[0]),localStorage.setItem(`ktgb_phone`,N),tt(r[0]),nt(N),K({reference_no:r[0],booking_status:`Pending`,payment_status:`Pending`,message:`Payment and administrator approval are pending.`}),T(5),bt()}}catch(e){D(e?.response?.data?.message||e?.response?.data?.error||`An error occurred during booking. Please try again.`),T(1)}finally{Re(!1)}},Lt=async()=>{if(!U||!W){at(`Enter your booking reference number and phone number.`);return}rt(!0),at(``);try{let e=await o(U.trim().toUpperCase(),W.trim());K(e.data.data),k(t=>t&&{...t,...e.data.data}),localStorage.setItem(`ktgb_reference`,U.trim().toUpperCase()),localStorage.setItem(`ktgb_phone`,W.trim()),e.data.data?.booking_status===`Confirmed`&&bt()}catch(e){K(null),at(e?.response?.data?.message||`Unable to check this booking right now.`)}finally{rt(!1)}},Rt=e=>{ut(e.target.value.replace(/\D/g,``).slice(0,16).replace(/(.{4})/g,`$1 `).trim())},zt=e=>{let t=e.target.value.replace(/\D/g,``).slice(0,4);ft(t.length>2?`${t.slice(0,2)}/${t.slice(2)}`:t)},Bt=()=>It(),Vt=Ct(x),Ht=wt(x),Ut=x.toLocaleString(`default`,{month:`long`,year:`numeric`}),$=[];for(let e=0;e<Ht;e++)$.push({day:null,empty:!0});for(let e=1;e<=Vt;e++){let t=S[Dt(x.getFullYear(),x.getMonth(),e)]||`available`,n=new Date(x.getFullYear(),x.getMonth(),e),r=!1,i=!1,a=!1,o=new Date().toDateString()===n.toDateString();if(m&&h){let e=m.getTime(),t=h.getTime(),o=n.getTime();o===e?r=!0:o===t?i=!0:o>e&&o<t&&(a=!0)}else m&&m.getTime()===n.getTime()&&(r=!0);$.push({day:e,empty:!1,status:t,isSelected:r,isCheckoutDay:i,isInRange:a,isToday:o,date:n})}return(0,f.jsxs)(`div`,{style:{background:`var(--off-white)`,minHeight:`100vh`,paddingBottom:`4rem`},children:[(0,f.jsxs)(`section`,{className:`bk-hero`,children:[(0,f.jsx)(`div`,{className:`bk-hero-bg`,style:s.background?.image?{backgroundImage:`url("${s.background.image}")`}:void 0}),(0,f.jsx)(`div`,{className:`bk-hero-overlay`}),(0,f.jsxs)(`div`,{className:`bk-hero-inner`,children:[(0,f.jsxs)(`div`,{className:`bk-hero-left`,children:[(0,f.jsxs)(`div`,{className:`bk-hero-eyebrow`,children:[(0,f.jsx)(_e,{size:12,style:{marginRight:`4px`,verticalAlign:`middle`}}),`CMA Circuit Bungalow · Kataragama`]}),(0,f.jsxs)(`h1`,{className:`bk-hero-title`,style:{marginTop:`10px`},children:[`Serene Retreat in`,(0,f.jsx)(`br`,{}),(0,f.jsx)(`em`,{children:`Sacred Kataragama`})]}),(0,f.jsx)(`p`,{className:`bk-hero-desc`,children:(0,f.jsx)(u,{children:`Reserve your stay at the Condominium Management Authority's exclusive circuit bungalow — nestled in the heart of Kataragama, offering tranquil accommodation for staff and visiting guests.`})})]}),(0,f.jsx)(`div`,{className:`bk-hero-gallery`,children:[`gallery_1`,`gallery_2`,`gallery_3`].map(e=>s[e]?.image&&(0,f.jsx)(`div`,{className:`bk-gallery-img`,children:(0,f.jsx)(`img`,{src:s[e].image,alt:s[e].alt_text||`Kataragama bungalow`})},e))})]})]}),(0,f.jsx)(`div`,{className:`role-selector-sec`,children:(0,f.jsx)(`div`,{className:`role-selector-inner`,children:(0,f.jsxs)(`div`,{className:`role-row`,children:[(0,f.jsx)(`span`,{className:`role-label`,children:(0,f.jsx)(u,{children:`I am a:`})}),(0,f.jsxs)(`button`,{className:`role-btn${p===`guest`?` active`:``}`,onClick:()=>{we(`guest`),v([])},children:[(0,f.jsx)(ge,{size:14}),`Visiting Guest`,(0,f.jsx)(`span`,{className:`role-badge`,children:(0,f.jsx)(u,{children:`Public`})})]}),(0,f.jsxs)(`span`,{style:{marginLeft:`auto`,fontSize:`12.5px`,color:`var(--text-muted)`,display:`flex`,alignItems:`center`,gap:`4px`},children:[(0,f.jsx)(l,{size:14,style:{color:`var(--success)`}}),`Secure Booking Portal · Condominium Management Authority`]})]})})}),(0,f.jsx)(`div`,{style:{maxWidth:`1280px`,margin:`0 auto`,padding:`40px 24px`},children:(0,f.jsxs)(`div`,{className:`booking-layout`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`div`,{className:`avail-card`,style:{padding:`24px`,borderRadius:`12px`,background:`#fff`,border:`1px solid #eee`,boxShadow:`var(--shadow-sm)`,marginBottom:`30px`},children:[(0,f.jsxs)(`h3`,{style:{margin:`0 0 20px 0`,display:`flex`,alignItems:`center`,gap:`8px`,borderBottom:`1px solid #eee`,paddingBottom:`12px`,color:`var(--text-dark)`},children:[(0,f.jsx)(ve,{size:18,style:{color:`var(--crimson)`}}),`Select Stay Period & Check Availability`]}),(0,f.jsxs)(`div`,{className:`bk-availability-grid`,style:{display:`grid`,gridTemplateColumns:`1.2fr 1fr`,gap:`30px`},children:[(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`div`,{style:{background:`rgba(139, 0, 0, 0.05)`,border:`1px solid rgba(139, 0, 0, 0.15)`,borderRadius:`8px`,padding:`12px 16px`,marginBottom:`20px`,display:`flex`,alignItems:`flex-start`,gap:`10px`},children:[(0,f.jsx)(ue,{size:16,style:{color:`var(--crimson)`,marginTop:`2px`,flexShrink:0}}),(0,f.jsxs)(`div`,{style:{fontSize:`13px`,color:`#555`,lineHeight:`1.4`},children:[(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`Bungalow Stay Policy:`})}),` Check-in is fixed at `,(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`1:00 PM`})}),` on the arrival date, and check-out is fixed at `,(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`10:00 AM`})}),` on the departure date. This stay period is automatically calculated as one day.`]})]}),(0,f.jsxs)(`div`,{className:`bk-dates-input-grid`,style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:`20px`,marginBottom:`20px`},children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`label`,{htmlFor:`checkin-date`,style:{display:`block`,fontWeight:600,fontSize:`13px`,color:`var(--text-dark)`,marginBottom:`8px`},children:`Check-in Date *`}),(0,f.jsxs)(`div`,{style:{position:`relative`,display:`flex`,alignItems:`center`},children:[(0,f.jsx)(`input`,{id:`checkin-date`,name:`checkin-date`,type:`date`,className:`bk-form-input`,style:{width:`100%`,padding:`10px 14px`,paddingRight:`80px`,borderRadius:`8px`,border:`1px solid #ddd`,fontSize:`14px`,background:`#fff`,color:`var(--text-dark)`},value:g.split(`T`)[0]||``,onChange:e=>{let t=e.target.value;if(t){if(S[t]===`booked`){window.alert(`This date is already booked. Please select another date.`);return}let e=`${t}T13:00`;De(e),Te(new Date(e))}else De(``),Te(null)},min:new Date().toISOString().split(`T`)[0]}),(0,f.jsx)(`span`,{style:{position:`absolute`,right:`12px`,fontSize:`12px`,color:`var(--crimson)`,fontWeight:`700`,pointerEvents:`none`},children:(0,f.jsx)(u,{children:`1:00 PM`})})]})]}),(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`label`,{htmlFor:`checkout-date`,style:{display:`block`,fontWeight:600,fontSize:`13px`,color:`var(--text-dark)`,marginBottom:`8px`},children:`Check-out Date *`}),(0,f.jsxs)(`div`,{style:{position:`relative`,display:`flex`,alignItems:`center`},children:[(0,f.jsx)(`input`,{id:`checkout-date`,name:`checkout-date`,type:`date`,className:`bk-form-input`,style:{width:`100%`,padding:`10px 14px`,paddingRight:`80px`,borderRadius:`8px`,border:`1px solid #ddd`,fontSize:`14px`,background:`#fff`,color:`var(--text-dark)`},value:Oe.split(`T`)[0]||``,onChange:e=>{let t=e.target.value;if(t){if(S[t]===`booked`){window.alert(`This date is already booked. Please select another date.`);return}let e=`${t}T10:00`;ke(e),Ee(new Date(e))}else ke(``),Ee(null)},min:g?g.split(`T`)[0]:new Date().toISOString().split(`T`)[0]}),(0,f.jsx)(`span`,{style:{position:`absolute`,right:`12px`,fontSize:`12px`,color:`var(--crimson)`,fontWeight:`700`,pointerEvents:`none`},children:(0,f.jsx)(u,{children:`10:00 AM`})})]})]})]}),m&&h&&(0,f.jsxs)(`div`,{style:{background:`rgba(201, 162, 39, 0.1)`,border:`1px solid rgba(201, 162, 39, 0.3)`,borderRadius:`8px`,padding:`12px 16px`,display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,f.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`8px`,fontSize:`13.5px`,color:`var(--text-dark)`},children:[(0,f.jsx)(ue,{size:16,style:{color:`#C9A227`}}),(0,f.jsx)(`span`,{children:(0,f.jsx)(u,{children:`Staying Duration:`})}),(0,f.jsxs)(`strong`,{children:[Y,` Day(s)`]})]}),(0,f.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`(Calculated automatically)`})})]})]}),(0,f.jsxs)(`div`,{style:{borderLeft:`1px solid #eee`,paddingLeft:`30px`},children:[(0,f.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:`12px`},children:[(0,f.jsx)(`span`,{style:{fontWeight:700,fontSize:`13.5px`,color:`var(--text-dark)`},children:(0,f.jsx)(u,{children:`Availability Calendar`})}),(0,f.jsxs)(`div`,{style:{display:`flex`,gap:`4px`,alignItems:`center`},children:[(0,f.jsx)(`button`,{type:`button`,style:{padding:`2px 8px`,background:`none`,border:`1px solid #ddd`,borderRadius:`4px`,cursor:`pointer`,fontSize:`12px`},onClick:Tt,children:`◀`}),(0,f.jsx)(`span`,{style:{fontSize:`12px`,fontWeight:`600`,minWidth:`90px`,textAlign:`center`,display:`inline-block`},children:Ut}),(0,f.jsx)(`button`,{type:`button`,style:{padding:`2px 8px`,background:`none`,border:`1px solid #ddd`,borderRadius:`4px`,cursor:`pointer`,fontSize:`12px`},onClick:Et,children:`▶`})]})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`4px`},children:[(0,f.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(7, 1fr)`,textAlign:`center`,fontSize:`11px`,fontWeight:`700`,color:`var(--text-muted)`},children:[(0,f.jsx)(`span`,{children:(0,f.jsx)(u,{children:`S`})}),(0,f.jsx)(`span`,{children:(0,f.jsx)(u,{children:`M`})}),(0,f.jsx)(`span`,{children:(0,f.jsx)(u,{children:`T`})}),(0,f.jsx)(`span`,{children:(0,f.jsx)(u,{children:`W`})}),(0,f.jsx)(`span`,{children:(0,f.jsx)(u,{children:`T`})}),(0,f.jsx)(`span`,{children:(0,f.jsx)(u,{children:`F`})}),(0,f.jsx)(`span`,{children:(0,f.jsx)(u,{children:`S`})})]}),(0,f.jsx)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(7, 1fr)`,gap:`4px`},children:$.map((e,t)=>{if(e.empty)return(0,f.jsx)(`div`,{style:{height:`24px`}},`tiny-empty-${t}`);let n=e.status===`booked`,r=e.status===`partial`,i=`#eaf5ee`,a=`#2e6b4a`,o=`Available`;return n?(i=`#fbebeb`,a=`#c93b3b`,o=`Booked`):r&&(i=`#fff4eb`,a=`#d4622a`,o=`Partial`),(0,f.jsx)(`div`,{title:`Day ${e.day}: ${o}`,style:{height:`26px`,display:`flex`,alignItems:`center`,justifyContent:`center`,borderRadius:`6px`,fontSize:`11.5px`,fontWeight:`600`,background:i,color:a,border:e.isToday?`1px solid #C9A227`:`none`,position:`relative`},children:e.day},`tiny-day-${e.day}`)})})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,gap:`12px`,justifyContent:`center`,marginTop:`16px`,fontSize:`11px`},children:[(0,f.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`4px`},children:[(0,f.jsx)(`div`,{style:{width:8,height:8,borderRadius:`50%`,background:`#2e6b4a`}}),` Available`]}),(0,f.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`4px`},children:[(0,f.jsx)(`div`,{style:{width:8,height:8,borderRadius:`50%`,background:`#d4622a`}}),` Partial`]}),(0,f.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`4px`},children:[(0,f.jsx)(`div`,{style:{width:8,height:8,borderRadius:`50%`,background:`#c93b3b`}}),` Booked`]})]})]})]})]}),(0,f.jsxs)(`div`,{className:`rooms-sec`,children:[(0,f.jsx)(`div`,{className:`rooms-sec-head`,children:(0,f.jsx)(`h3`,{style:{margin:0},children:(0,f.jsx)(u,{children:`Select Your Room`})})}),(0,f.jsx)(`div`,{className:`rooms-grid`,children:Se?(0,f.jsx)(`div`,{style:{gridColumn:`1 / -1`,textAlign:`center`,padding:`3rem`,color:`var(--text-muted)`},children:`Loading available guesthouse rooms...`}):ne.length===0?(0,f.jsx)(`div`,{style:{gridColumn:`1 / -1`,textAlign:`center`,padding:`3rem`,color:`var(--text-muted)`},children:`No rooms configured at this time.`}):ne.map(e=>{let t=_.some(t=>t.id===e.id),n=X(e);return(0,f.jsxs)(`div`,{className:`room-card${t?` selected-room`:``}`,onClick:()=>Ae(e),children:[e.image?(0,f.jsx)(`img`,{src:e.image.startsWith(`http`)?e.image:oe(e.image),alt:e.name,className:`room-img`,onError:e=>{e.target.style.display=`none`,e.target.nextSibling.style.display=`flex`}}):null,(0,f.jsx)(`div`,{className:`room-img-placeholder`,style:{display:e.image?`none`:`flex`,fontSize:`2.5rem`},children:e.emoji||`🛏️`}),(0,f.jsxs)(`div`,{className:`room-body`,children:[(0,f.jsx)(`h4`,{className:`room-name`,style:{margin:0},children:e.name}),(0,f.jsxs)(`div`,{className:`room-meta`,style:{marginTop:`8px`},children:[(0,f.jsxs)(`div`,{className:`room-meta-item`,children:[(0,f.jsx)(be,{size:13}),` `,e.beds]}),(0,f.jsxs)(`div`,{className:`room-meta-item`,children:[(0,f.jsx)(he,{size:13}),` `,e.capacity]}),e.ac&&(0,f.jsxs)(`div`,{className:`room-meta-item`,children:[(0,f.jsx)(de,{size:13}),` A/C`]}),(0,f.jsxs)(`div`,{className:`room-meta-item`,children:[(0,f.jsx)(pe,{size:13}),` `,e.view]})]}),(0,f.jsx)(`div`,{className:`room-price-row`,style:{marginTop:`16px`},children:(0,f.jsxs)(`div`,{className:`room-price`,children:[`Rs. `,Number(n).toLocaleString(),(0,f.jsxs)(`span`,{style:{fontSize:`11px`,color:`var(--text-muted)`,fontWeight:400},children:[` `,`/ night `,p===`employee`&&`(Staff)`]})]})}),(0,f.jsx)(`button`,{className:`room-select-btn`,type:`button`,onClick:t=>{t.stopPropagation(),Ae(e)},children:t?`✓ Selected`:`Select Room`})]})]},e.id)})})]})]}),(0,f.jsxs)(`div`,{className:`booking-sidebar`,children:[(0,f.jsxs)(`div`,{className:`bk-summary-card`,children:[(0,f.jsxs)(`div`,{className:`bk-sum-head`,children:[(0,f.jsx)(`h4`,{style:{margin:0},children:(0,f.jsx)(u,{children:`Booking Summary`})}),(0,f.jsx)(`p`,{style:{margin:`4px 0 0`,fontSize:`11.5px`,opacity:.85},children:(0,f.jsx)(u,{children:`Review your reservation`})})]}),(0,f.jsxs)(`div`,{className:`bk-sum-body`,children:[(0,f.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,f.jsx)(`span`,{className:`bk-sum-label`,children:(0,f.jsx)(u,{children:`Property`})}),(0,f.jsx)(`span`,{className:`bk-sum-value`,children:(0,f.jsx)(u,{children:`Kataragama Bungalow`})})]}),(0,f.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,f.jsx)(`span`,{className:`bk-sum-label`,children:(0,f.jsx)(u,{children:`Room(s)`})}),(0,f.jsx)(`span`,{className:`bk-sum-value`,children:_.length>0?_.map(e=>e.name).join(`, `):`Not selected`})]}),(0,f.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,f.jsx)(`span`,{className:`bk-sum-label`,children:(0,f.jsx)(u,{children:`Check-In`})}),(0,f.jsx)(`span`,{className:`bk-sum-value`,children:Q(m)})]}),(0,f.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,f.jsx)(`span`,{className:`bk-sum-label`,children:(0,f.jsx)(u,{children:`Check-Out`})}),(0,f.jsx)(`span`,{className:`bk-sum-value`,children:Q(h)})]}),(0,f.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,f.jsx)(`span`,{className:`bk-sum-label`,children:(0,f.jsx)(u,{children:`Nights`})}),(0,f.jsx)(`span`,{className:`bk-sum-value`,children:Y>0?`${Y} night${Y>1?`s`:``}`:`—`})]}),(0,f.jsxs)(`div`,{className:`bk-sum-row`,children:[(0,f.jsx)(`span`,{className:`bk-sum-label`,children:(0,f.jsx)(u,{children:`Guests`})}),(0,f.jsxs)(`span`,{className:`bk-sum-value`,children:[y,` Adult(s), `,b,` Child(ren)`]})]}),_.length>0&&(0,f.jsxs)(`div`,{className:`bk-sum-row`,style:{flexDirection:`column`,alignItems:`flex-start`,gap:`4px`},children:[(0,f.jsx)(`span`,{className:`bk-sum-label`,children:p===`employee`?`Staff Rate/Night`:`Rate/Night`}),(0,f.jsx)(`div`,{style:{width:`100%`,paddingLeft:`8px`,fontSize:`12px`,color:`var(--text-muted)`},children:_.map(e=>(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,f.jsxs)(`span`,{children:[e.name,`:`]}),(0,f.jsxs)(`span`,{children:[`Rs. `,X(e).toLocaleString()]})]},e.id))})]}),(0,f.jsxs)(`div`,{className:`bk-sum-total`,children:[(0,f.jsx)(`span`,{className:`bk-sum-total-label`,children:(0,f.jsx)(u,{children:`Total Amount`})}),(0,f.jsxs)(`span`,{className:`bk-sum-total-val`,children:[`Rs. `,Z().toLocaleString()]})]}),(0,f.jsxs)(`button`,{className:`bk-proceed-btn`,type:`button`,onClick:kt,disabled:_.length===0||!m||!h||Y<=0,children:[(0,f.jsx)(me,{size:15}),`Proceed to Book`]}),(0,f.jsxs)(`div`,{className:`bk-trust-items`,style:{marginTop:`16px`},children:[(0,f.jsxs)(`div`,{className:`bk-trust-item`,children:[(0,f.jsx)(l,{size:14,style:{color:`var(--success)`}}),` Secure SSL Booking`]}),(0,f.jsxs)(`div`,{className:`bk-trust-item`,children:[(0,f.jsx)(l,{size:14,style:{color:`var(--success)`}}),` Free Cancellation 48hrs prior`]}),(0,f.jsxs)(`div`,{className:`bk-trust-item`,children:[(0,f.jsx)(l,{size:14,style:{color:`var(--success)`}}),` Admin-reviewed reservation`]})]})]})]}),(0,f.jsxs)(`div`,{style:{background:`#fff`,borderRadius:`12px`,border:`1px solid #eee`,padding:`20px`,boxShadow:`var(--shadow-sm)`,marginBottom:`20px`},children:[(0,f.jsxs)(`div`,{style:{fontWeight:700,display:`flex`,alignItems:`center`,gap:`6px`,color:`var(--text-dark)`,marginBottom:`6px`},children:[(0,f.jsx)(le,{size:16,style:{color:`var(--crimson)`}}),`Check Booking Status`]}),(0,f.jsx)(`p`,{style:{margin:`0 0 12px`,color:`var(--text-muted)`,fontSize:`12px`,lineHeight:1.5},children:`Enter the reference and phone number used for your request.`}),(0,f.jsx)(`input`,{className:`bk-form-input`,placeholder:`KTGB008723`,value:U,onChange:e=>tt(e.target.value.toUpperCase()),style:{marginBottom:`8px`}}),(0,f.jsx)(`input`,{className:`bk-form-input`,placeholder:`Phone number`,value:W,onChange:e=>nt(e.target.value),style:{marginBottom:`8px`}}),(0,f.jsxs)(`button`,{type:`button`,className:`bk-proceed-btn`,onClick:Lt,disabled:q,children:[q?(0,f.jsx)(c,{size:15,style:{animation:`spin 1s linear infinite`}}):(0,f.jsx)(pe,{size:15}),`Check Status`]}),it&&(0,f.jsx)(`div`,{style:{marginTop:`10px`,color:`#b91c1c`,fontSize:`12px`},children:it}),G&&(0,f.jsxs)(`div`,{style:{marginTop:`12px`,padding:`12px`,borderRadius:`8px`,background:G.booking_status===`Confirmed`?`#ecfdf5`:G.booking_status===`Cancelled`?`#fef2f2`:`#fffbeb`,border:`1px solid #e5e7eb`,fontSize:`12px`,lineHeight:1.6},children:[(0,f.jsx)(`strong`,{style:{display:`block`,color:G.booking_status===`Confirmed`?`#15803d`:G.booking_status===`Cancelled`?`#b91c1c`:`#b45309`},children:G.booking_status===`Confirmed`?`Booking Successful`:G.booking_status===`Cancelled`?`Booking Not Approved`:`Pending Approval`}),(0,f.jsxs)(`div`,{children:[`Reference: `,(0,f.jsx)(`b`,{children:G.reference_no})]}),(0,f.jsxs)(`div`,{children:[`Payment: `,(0,f.jsx)(`b`,{children:G.payment_status})]}),(0,f.jsx)(`div`,{children:G.message})]})]}),(0,f.jsxs)(`div`,{style:{background:`#fff`,borderRadius:`12px`,border:`1px solid #eee`,padding:`20px`,boxShadow:`var(--shadow-sm)`},children:[(0,f.jsxs)(`div`,{style:{fontWeight:700,display:`flex`,alignItems:`center`,gap:`6px`,color:`var(--text-dark)`,marginBottom:`12px`},children:[(0,f.jsx)(ce,{size:14,style:{color:`var(--crimson)`}}),`Need Booking Assistance?`]}),(0,f.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`8px`,fontSize:`13px`,color:`var(--text-muted)`},children:[(0,f.jsx)(`div`,{children:`📞 0112447432`}),(0,f.jsx)(`div`,{children:`✉ bungalow@condominium.lk`}),(0,f.jsx)(`div`,{children:`🕒 Mon–Fri, 8:30am–4:30pm`})]})]}),(0,f.jsxs)(`div`,{style:{background:`#fff`,borderRadius:`12px`,border:`1px solid #eee`,padding:`20px`,boxShadow:`var(--shadow-sm)`,marginTop:`20px`},children:[(0,f.jsxs)(`div`,{style:{fontWeight:700,display:`flex`,alignItems:`center`,gap:`6px`,color:`var(--text-dark)`,marginBottom:`12px`},children:[(0,f.jsx)(se,{size:14,style:{color:`var(--crimson)`}}),`Bungalow Location`]}),(0,f.jsx)(`p`,{style:{margin:`0 0 12px 0`,fontSize:`13px`,color:`var(--text-muted)`,lineHeight:`1.4`},children:(0,f.jsx)(u,{children:`Detour Road, Kataragama, Sri Lanka. Conveniently situated close to the sacred temples.`})}),(0,f.jsxs)(`a`,{href:`https://maps.app.goo.gl/PkPj7oFnBFLMbA9n7`,target:`_blank`,rel:`noopener noreferrer`,style:{display:`flex`,alignItems:`center`,justifyContent:`center`,gap:`6px`,textDecoration:`none`,backgroundColor:`var(--crimson)`,color:`#fff`,border:`none`,borderRadius:`6px`,padding:`8px 12px`,fontSize:`13px`,fontWeight:`600`,transition:`background-color 0.2s ease`,cursor:`pointer`},onMouseOver:e=>e.currentTarget.style.backgroundColor=`#6b0000`,onMouseOut:e=>e.currentTarget.style.backgroundColor=`var(--crimson)`,children:[(0,f.jsx)(fe,{size:14}),`View on Google Maps`]})]})]})]})}),(0,f.jsx)(`section`,{className:`section facilities-sec`,children:(0,f.jsxs)(`div`,{className:`container`,children:[(0,f.jsxs)(`div`,{style:{textAlign:`center`,marginBottom:`40px`},children:[(0,f.jsx)(`span`,{className:`section-label`,children:(0,f.jsx)(u,{children:`Amenities`})}),(0,f.jsx)(`h2`,{className:`section-title`,children:(0,f.jsx)(u,{children:`Bungalow Facilities`})}),(0,f.jsx)(`p`,{className:`section-subtitle`,style:{margin:`0 auto`},children:(0,f.jsx)(u,{children:`Enjoy standard facilities at the CMA Circuit Bungalow — designed for a comfortable retreat.`})})]}),(0,f.jsxs)(`div`,{className:`facilities-grid`,children:[(0,f.jsxs)(`div`,{className:`facility-card`,children:[(0,f.jsx)(`span`,{className:`facility-icon`,children:`🛏️`}),(0,f.jsx)(`h4`,{className:`facility-name`,children:(0,f.jsx)(u,{children:`Comfortable Rooms`})}),(0,f.jsx)(`p`,{className:`facility-desc`,children:(0,f.jsx)(u,{children:`Quality beds, linen, hot water showers, and optional AC setups.`})})]}),(0,f.jsxs)(`div`,{className:`facility-card`,children:[(0,f.jsx)(`span`,{className:`facility-icon`,children:`🍽️`}),(0,f.jsx)(`h4`,{className:`facility-name`,children:(0,f.jsx)(u,{children:`Dining Hall`})}),(0,f.jsx)(`p`,{className:`facility-desc`,children:(0,f.jsx)(u,{children:`Spacious seating with kitchen setups available for visiting guests.`})})]}),(0,f.jsxs)(`div`,{className:`facility-card`,children:[(0,f.jsx)(`span`,{className:`facility-icon`,children:`🌿`}),(0,f.jsx)(`h4`,{className:`facility-name`,children:(0,f.jsx)(u,{children:`Surrounding Gardens`})}),(0,f.jsx)(`p`,{className:`facility-desc`,children:(0,f.jsx)(u,{children:`Beautiful lush courtyard garden surrounding the premises.`})})]}),(0,f.jsxs)(`div`,{className:`facility-card`,children:[(0,f.jsx)(`span`,{className:`facility-icon`,children:`🅿️`}),(0,f.jsx)(`h4`,{className:`facility-name`,children:(0,f.jsx)(u,{children:`Free Vehicle Parking`})}),(0,f.jsx)(`p`,{className:`facility-desc`,children:(0,f.jsx)(u,{children:`On-site secure parking space inside the gated boundaries.`})})]})]})]})}),Le&&(0,f.jsx)(`div`,{className:`bk-modal-overlay open`,children:(0,f.jsxs)(`div`,{className:`bk-modal`,children:[(0,f.jsxs)(`div`,{className:`bk-modal-head`,children:[(0,f.jsx)(`span`,{className:`bk-modal-title`,children:(0,f.jsx)(u,{children:`Complete Reservation`})}),(0,f.jsx)(`button`,{className:`bk-modal-close`,onClick:()=>C(!1),children:`✕`})]}),(0,f.jsxs)(`div`,{className:`bk-modal-body`,children:[(0,f.jsxs)(`div`,{className:`bk-steps`,style:{justifyContent:`center`,gap:`40px`},children:[(0,f.jsxs)(`div`,{className:`bk-step${w>=1?` active`:``}${w>1?` done`:``}`,children:[(0,f.jsx)(`div`,{className:`bk-step-circle`,children:`1`}),(0,f.jsx)(`div`,{className:`bk-step-label`,children:`Guest Info`})]}),(0,f.jsxs)(`div`,{className:`bk-step${w===5?` active`:``}`,children:[(0,f.jsx)(`div`,{className:`bk-step-circle`,children:`✓`}),(0,f.jsx)(`div`,{className:`bk-step-label`,children:`Done`})]})]}),w===1&&(0,f.jsxs)(`div`,{className:`bk-form-section active`,children:[(0,f.jsx)(`h4`,{style:{margin:`0 0 16px`,fontWeight:700},children:(0,f.jsx)(u,{children:`Guest Information`})}),(0,f.jsxs)(`div`,{style:{background:`#fef3c7`,border:`1px solid #fde68a`,color:`#92400e`,borderRadius:`8px`,padding:`10px 14px`,fontSize:`12px`,marginBottom:`16px`,display:`flex`,alignItems:`center`,gap:`8px`},children:[(0,f.jsx)(`span`,{style:{fontSize:`14px`},children:`⏰`}),(0,f.jsxs)(`span`,{children:[(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:` stay period limits:`})}),` check-in starts at `,(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`2:00 p.m.`})}),`, check-out is strictly before `,(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`10:00 a.m.`})})]})]}),(0,f.jsxs)(`div`,{className:`bk-form-row`,children:[(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`First Name *`}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:A,onChange:e=>Be(e.target.value),required:!0})]}),(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`Last Name *`}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:j,onChange:e=>Ve(e.target.value),required:!0})]})]}),(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`NIC / Passport Number *`}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:M,onChange:e=>He(e.target.value),required:!0})]}),(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`Permanent Address *`}),(0,f.jsx)(`textarea`,{className:`bk-form-input`,rows:2,value:I,onChange:e=>Je(e.target.value),required:!0,placeholder:`Enter your full permanent address`})]}),(0,f.jsxs)(`div`,{className:`bk-form-row`,children:[(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`Mobile Number *`}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:N,onChange:e=>Ue(e.target.value),required:!0})]}),(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`Email Address *`}),(0,f.jsx)(`input`,{type:`email`,className:`bk-form-input`,value:P,onChange:e=>We(e.target.value),required:!0})]})]}),(0,f.jsxs)(`div`,{className:`bk-form-row`,style:{gridTemplateColumns:`1.2fr 1fr`,alignItems:`center`},children:[(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`Occupation *`}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,value:L,onChange:e=>Ye(e.target.value),required:!0,placeholder:`e.g. Government Executive`})]}),(0,f.jsxs)(`div`,{className:`bk-form-group`,style:{display:`flex`,alignItems:`center`,marginTop:`1.25rem`},children:[(0,f.jsx)(`input`,{type:`checkbox`,id:`isCmaEmpCheckbox`,checked:z,onChange:e=>Ze(e.target.checked),style:{width:`18px`,height:`18px`,marginRight:`8px`,cursor:`pointer`}}),(0,f.jsx)(`label`,{htmlFor:`isCmaEmpCheckbox`,style:{fontSize:`13px`,fontWeight:600,color:`#374151`,cursor:`pointer`},children:`Employed at Ministry / CMA?`})]})]}),(0,f.jsxs)(`div`,{style:{background:`#fafafa`,border:`1px dashed var(--mid-gray)`,borderRadius:`10px`,padding:`14px`,marginBottom:`16px`},children:[(0,f.jsx)(`label`,{className:`bk-form-label`,style:{margin:0,fontWeight:700,fontSize:`13px`},children:`Government Institution Employee? (Optional)`}),(0,f.jsx)(`span`,{style:{fontSize:`11px`,color:`#64748b`,display:`block`,marginBottom:`8px`,lineHeight:1.4},children:(0,f.jsx)(u,{children:`If employed in a government institution, please attach an official letter confirming employment.`})}),n?(0,f.jsx)(`input`,{type:`file`,accept:`.pdf,image/*`,onChange:At,style:{display:`block`,fontSize:`12px`,width:`100%`}}):(0,f.jsx)(`div`,{style:{fontSize:`11.5px`,color:`#64748b`},children:`Citizen sign-in is required only when attaching an official letter. You can submit a normal guest request without one.`}),$e&&(0,f.jsx)(`div`,{style:{fontSize:`11px`,color:`var(--crimson)`,marginTop:`4px`,fontWeight:600},children:`Uploading official letter...`}),R&&(0,f.jsx)(`div`,{style:{fontSize:`11px`,color:`#16a34a`,marginTop:`4px`,fontWeight:600},children:`✓ Official letter uploaded successfully.`})]}),p===`employee`&&(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`CMA Employee ID *`}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`e.g. CMA-STF-889`,value:F,onChange:e=>Ge(e.target.value),required:!0}),(0,f.jsx)(`div`,{className:`bk-form-hint`,children:`Please enter your official employee credentials.`})]}),(0,f.jsxs)(`div`,{className:`bk-form-row`,children:[(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`No. of Adults *`}),(0,f.jsxs)(`select`,{className:`bk-form-select`,value:y,onChange:e=>je(e.target.value),children:[(0,f.jsx)(`option`,{value:1,children:`1`}),(0,f.jsx)(`option`,{value:2,children:`2`}),(0,f.jsx)(`option`,{value:3,children:`3`}),(0,f.jsx)(`option`,{value:4,children:`4`})]})]}),(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`No. of Children`}),(0,f.jsxs)(`select`,{className:`bk-form-select`,value:b,onChange:e=>Me(e.target.value),children:[(0,f.jsx)(`option`,{value:0,children:`0`}),(0,f.jsx)(`option`,{value:1,children:`1`}),(0,f.jsx)(`option`,{value:2,children:`2`}),(0,f.jsx)(`option`,{value:3,children:`3`})]})]})]}),(0,f.jsxs)(`div`,{style:{border:`1.5px solid var(--mid-gray)`,borderRadius:`10px`,padding:`16px`,marginBottom:`16px`,background:`#fff`},children:[(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,marginBottom:`12px`,flexWrap:`wrap`,gap:`8px`},children:[(0,f.jsxs)(`label`,{className:`bk-form-label`,style:{margin:0,fontWeight:700,fontSize:`13px`},children:[`Accompanying Family Members (`,B,`)`]}),(0,f.jsx)(`button`,{type:`button`,onClick:jt,style:{padding:`4px 8px`,fontSize:`11px`,background:`var(--light-gray)`,border:`1px solid var(--mid-gray)`,borderRadius:`6px`,cursor:`pointer`,fontWeight:600},children:`+ Add Accompanying Member`})]}),V.length===0?(0,f.jsx)(`div`,{style:{fontSize:`12px`,color:`#64748b`,padding:`10px`,textAlign:`center`,background:`var(--off-white)`,borderRadius:`6px`},children:`No family members registered. Accompanying members can be added above.`}):(0,f.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`10px`},children:V.map((e,t)=>(0,f.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr auto`,gap:`8px`,alignItems:`center`},children:[(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`Family Member Name`,value:e.name,onChange:e=>Nt(t,`name`,e.target.value),style:{padding:`6px 8px`,fontSize:`12px`},required:!0}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`NIC No. / Passport`,value:e.nic,onChange:e=>Nt(t,`nic`,e.target.value),style:{padding:`6px 8px`,fontSize:`12px`},required:!0}),(0,f.jsx)(`button`,{type:`button`,onClick:()=>Mt(t),style:{background:`#fee2e2`,border:`none`,borderRadius:`6px`,color:`#dc2626`,width:`28px`,height:`28px`,display:`flex`,alignItems:`center`,justifyContent:`center`,cursor:`pointer`,fontWeight:`bold`},children:`✕`})]},t))})]}),(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`Special Requests (Optional)`}),(0,f.jsx)(`textarea`,{className:`bk-form-input`,rows:2,value:Ke,onChange:e=>qe(e.target.value),placeholder:`Late check-in, dietary, ground floor...`})]}),(0,f.jsx)(`div`,{className:`bk-btn-row`,children:(0,f.jsxs)(`button`,{className:`bk-btn-next`,type:`button`,disabled:!A||!j||!M||!N||!P||!I||!L||p===`employee`&&!F||E,onClick:It,children:[E?(0,f.jsx)(c,{size:16,style:{animation:`spin 1s linear infinite`,marginRight:`6px`}}):null,`Proceed to Book`]})})]}),w===2&&(0,f.jsxs)(`div`,{className:`bk-form-section active`,children:[(0,f.jsx)(`h4`,{style:{margin:`0 0 16px`,fontWeight:700},children:(0,f.jsx)(u,{children:`Review Details`})}),(0,f.jsxs)(`div`,{style:{background:`#f9f9f9`,borderRadius:`12px`,border:`1px solid #eee`,padding:`16px`,display:`flex`,flexDirection:`column`,gap:`8px`,marginBottom:`18px`},children:[(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Guest Name`})}),(0,f.jsxs)(`strong`,{style:{color:`var(--text-dark)`},children:[A,` `,j]})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`NIC Number`})}),(0,f.jsx)(`strong`,{children:M})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Contact Details`})}),(0,f.jsxs)(`strong`,{children:[N,` | `,P]})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Permanent Address`})}),(0,f.jsx)(`strong`,{style:{maxWidth:`240px`,textAlign:`right`,whiteSpace:`pre-wrap`},children:I})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Occupation`})}),(0,f.jsx)(`strong`,{children:L})]}),z&&(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Ministry / CMA Staff`})}),(0,f.jsx)(`strong`,{style:{color:`#16a34a`},children:(0,f.jsx)(u,{children:`Yes`})})]}),R&&(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Official Gov Letter`})}),(0,f.jsx)(`strong`,{style:{color:`#16a34a`},children:(0,f.jsx)(u,{children:`Attached`})})]}),V.length>0&&(0,f.jsxs)(`div`,{style:{borderTop:`1px solid #eee`,paddingTop:`8px`,fontSize:`12.5px`},children:[(0,f.jsxs)(`div`,{style:{fontWeight:600,color:`var(--text-muted)`,marginBottom:`4px`},children:[`Accompanying Members (`,B,`):`]}),(0,f.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`4px`,background:`var(--off-white)`,padding:`8px`,borderRadius:`6px`},children:V.map((e,t)=>(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,f.jsxs)(`span`,{children:[`• `,e.name]}),(0,f.jsxs)(`span`,{style:{color:`var(--text-muted)`},children:[`NIC: `,e.nic]})]},t))})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`,borderTop:`1px solid #eee`,paddingTop:`8px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Room(s) Selection`})}),(0,f.jsx)(`strong`,{style:{color:`var(--crimson)`},children:_.map(e=>e.name).join(`, `)})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Check-In`})}),(0,f.jsx)(`strong`,{children:Q(m)})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Check-Out`})}),(0,f.jsx)(`strong`,{children:Q(h)})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Nights`})}),(0,f.jsxs)(`strong`,{children:[Y,` night`,Y>1?`s`:``]})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:`13.5px`,borderTop:`1px solid #eee`,paddingTop:`8px`},children:[(0,f.jsx)(`span`,{style:{color:`var(--text-muted)`},children:(0,f.jsx)(u,{children:`Total Amount`})}),(0,f.jsxs)(`strong`,{style:{fontSize:`16px`,color:`var(--crimson)`},children:[`Rs. `,Z().toLocaleString()]})]})]}),(0,f.jsxs)(`div`,{className:`bk-btn-row`,children:[(0,f.jsx)(`button`,{className:`bk-btn-back`,type:`button`,onClick:()=>T(1),children:`Back`}),(0,f.jsx)(`button`,{className:`bk-btn-next`,type:`button`,onClick:()=>T(3),children:`Proceed to Payment →`})]})]}),w===3&&(0,f.jsxs)(`div`,{className:`bk-form-section active`,children:[(0,f.jsx)(`h4`,{style:{margin:`0 0 16px`,fontWeight:700},children:(0,f.jsx)(u,{children:`Secure Payment Simulation`})}),(0,f.jsxs)(`div`,{className:`pay-methods`,children:[(0,f.jsxs)(`div`,{className:`pay-method${J===`card`?` active`:``}`,onClick:()=>ot(`card`),children:[(0,f.jsx)(`span`,{className:`pay-method-icon`,children:`💳`}),(0,f.jsx)(`div`,{className:`pay-method-label`,children:`Credit/Debit`})]}),(0,f.jsxs)(`div`,{className:`pay-method${J===`bank`?` active`:``}`,onClick:()=>ot(`bank`),children:[(0,f.jsx)(`span`,{className:`pay-method-icon`,children:`🏦`}),(0,f.jsx)(`div`,{className:`pay-method-label`,children:`Bank Transfer`})]}),(0,f.jsxs)(`div`,{className:`pay-method${J===`wallet`?` active`:``}`,onClick:()=>ot(`wallet`),children:[(0,f.jsx)(`span`,{className:`pay-method-icon`,children:`📱`}),(0,f.jsx)(`div`,{className:`pay-method-label`,children:`e-Wallet`})]})]}),J===`card`?(0,f.jsxs)(f.Fragment,{children:[(0,f.jsxs)(`div`,{className:`card-preview`,children:[(0,f.jsx)(`div`,{className:`card-chip`}),(0,f.jsx)(`div`,{className:`card-number`,children:lt||`•••• •••• •••• ••••`}),(0,f.jsxs)(`div`,{className:`card-info-row`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`div`,{className:`card-holder`,children:`Card Holder`}),(0,f.jsx)(`div`,{style:{fontSize:`13px`,fontWeight:700,color:`#fff`,textTransform:`uppercase`},children:st||`YOUR NAME`})]}),(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`div`,{className:`card-expiry`,children:`Expires`}),(0,f.jsx)(`div`,{style:{fontSize:`13px`,fontWeight:700,color:`#fff`},children:dt||`MM/YY`})]})]})]}),(0,f.jsxs)(`div`,{className:`pay-card-fields`,children:[(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`Cardholder Name *`}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`Kamal Perera`,value:st,onChange:e=>ct(e.target.value),required:!0})]}),(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`Card Number *`}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`4111 2222 3333 4444`,value:lt,onChange:Rt,required:!0})]}),(0,f.jsxs)(`div`,{className:`pay-card-row`,children:[(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`Expiry Date *`}),(0,f.jsx)(`input`,{type:`text`,className:`bk-form-input`,placeholder:`MM/YY`,value:dt,onChange:zt,required:!0})]}),(0,f.jsxs)(`div`,{className:`bk-form-group`,children:[(0,f.jsx)(`label`,{className:`bk-form-label`,children:`CVV *`}),(0,f.jsx)(`input`,{type:`password`,placeholder:`•••`,className:`bk-form-input`,value:pt,onChange:e=>mt(e.target.value.substring(0,3)),required:!0})]})]})]})]}):(0,f.jsx)(`div`,{style:{padding:`24px`,background:`#f9f9f9`,borderRadius:`12px`,border:`1px solid #eee`,fontSize:`13px`,color:`var(--text-muted)`,lineHeight:1.6,marginBottom:`16px`},children:`ℹ Selected payment method is in simulation mode. Standard demo checks require completing checkout via Credit/Debit card form and inputting the mock OTP verification code.`}),(0,f.jsxs)(`div`,{style:{background:`#f0fdf4`,border:`1px solid #bbf7d0`,borderRadius:`8px`,padding:`12px`,fontSize:`12.5px`,color:`#15803d`,display:`flex`,gap:`8px`,alignItems:`center`,marginBottom:`18px`},children:[(0,f.jsx)(me,{size:14}),(0,f.jsxs)(`span`,{children:[`SSL encrypted transaction. Booking amount: `,(0,f.jsxs)(`strong`,{children:[`Rs. `,Z().toLocaleString()]})]})]}),(0,f.jsxs)(`div`,{className:`bk-btn-row`,children:[(0,f.jsx)(`button`,{className:`bk-btn-back`,type:`button`,onClick:()=>T(2),children:`Back`}),(0,f.jsx)(`button`,{className:`bk-btn-next`,type:`button`,disabled:J===`card`&&(!st||!lt||!dt||!pt),onClick:()=>T(4),children:`Pay & Get OTP →`})]})]}),w===4&&(0,f.jsxs)(`div`,{className:`bk-form-section active`,children:[(0,f.jsxs)(`div`,{className:`otp-container`,children:[(0,f.jsx)(`div`,{className:`otp-icon`,children:`📲`}),(0,f.jsx)(`h3`,{className:`otp-heading`,style:{margin:0},children:(0,f.jsx)(u,{children:`OTP Verification`})}),(0,f.jsxs)(`p`,{className:`otp-sub`,style:{marginTop:`8px`},children:[`A 6-digit One-Time Password has been sent to your simulated mobile number `,(0,f.jsx)(`strong`,{children:N||`+94 77 *** ****`}),`. Please enter it below to confirm your payment.`]}),(0,f.jsx)(`div`,{className:`otp-input-row`,style:{display:`flex`,gap:`8px`,justifyContent:`center`,margin:`20px 0`},children:ht.map((e,t)=>(0,f.jsx)(`input`,{ref:e=>yt.current[t]=e,type:`text`,maxLength:1,className:`otp-digit`,value:e,onChange:e=>Pt(e,t),onKeyDown:e=>Ft(e,t),style:{width:`45px`,height:`52px`,borderRadius:`8px`,border:`2px solid #ddd`,textAlign:`center`,fontSize:`20px`,fontWeight:700}},t))}),(0,f.jsxs)(`div`,{className:`otp-resend`,style:{fontSize:`13px`},children:[`Didn't receive the OTP? `,(0,f.jsx)(`button`,{style:{color:`var(--crimson)`,fontWeight:700,border:`none`,background:`none`},onClick:()=>vt(60),children:`Resend`}),` `,_t>0&&(0,f.jsxs)(`span`,{className:`otp-timer`,children:[`(`,_t,`s)`]})]}),(0,f.jsxs)(`div`,{style:{background:`rgba(139,26,26,.06)`,borderRadius:`10px`,padding:`12px 16px`,fontSize:`12.5px`,color:`var(--text-body)`,margin:`20px 0 0`,textAlign:`left`,border:`1px dashed var(--crimson)`},children:[(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`Demo Simulation:`})}),` Enter `,(0,f.jsx)(`strong`,{style:{color:`var(--crimson)`},children:(0,f.jsx)(u,{children:`1 2 3 4 5 6`})}),` to verify transaction successfully.`]})]}),(0,f.jsxs)(`div`,{className:`bk-btn-row`,style:{marginTop:`24px`},children:[(0,f.jsx)(`button`,{className:`bk-btn-back`,type:`button`,onClick:()=>T(3),children:`Back`}),(0,f.jsxs)(`button`,{className:`bk-btn-next`,type:`button`,disabled:E,onClick:Bt,children:[E?(0,f.jsx)(c,{size:16,style:{animation:`spin 1s linear infinite`,marginRight:`6px`}}):null,`Confirm Booking & Pay`]})]})]}),w===5&&O&&(0,f.jsx)(`div`,{className:`bk-form-section active`,children:(0,f.jsxs)(`div`,{className:`bk-success`,children:[(0,f.jsx)(`div`,{className:`bk-success-icon`,style:{fontSize:`3.5rem`},children:O.booking_status===`Confirmed`?`✅`:`⏳`}),(0,f.jsx)(`h3`,{className:`bk-success-title`,style:{margin:`10px 0 0`},children:O.booking_status===`Confirmed`?`Booking Successful!`:`Booking Request Submitted`}),(0,f.jsx)(`p`,{className:`bk-success-sub`,style:{marginTop:`8px`,fontWeight:`600`,color:O.booking_status===`Confirmed`?`#15803d`:`#b45309`},children:O.booking_status===`Confirmed`?`Your reservation has been approved. The selected dates are now secured.`:`Payment is pending and your request is awaiting administrator approval. No payment has been collected online.`}),(0,f.jsxs)(`div`,{className:`bk-ref-box`,children:[(0,f.jsx)(`div`,{className:`bk-ref-label`,children:`Booking Reference Number`}),(0,f.jsx)(`div`,{className:`bk-ref-num`,children:O.allReferences?O.allReferences:O.reference_no})]}),(0,f.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:`10px`,margin:`14px 0`},children:[(0,f.jsxs)(`div`,{style:{padding:`10px`,borderRadius:`8px`,background:`#fffbeb`,border:`1px solid #fde68a`,color:`#92400e`,fontSize:`12px`},children:[`Payment: `,(0,f.jsx)(`strong`,{children:O.payment_status||`Pending`})]}),(0,f.jsxs)(`div`,{style:{padding:`10px`,borderRadius:`8px`,background:`#fffbeb`,border:`1px solid #fde68a`,color:`#92400e`,fontSize:`12px`},children:[`Approval: `,(0,f.jsx)(`strong`,{children:O.booking_status||`Pending`})]})]}),(0,f.jsxs)(`div`,{className:`bk-success-details`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`Room Type:`})}),(0,f.jsx)(`span`,{children:O.unit_number})]}),(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`Check-In Date:`})}),(0,f.jsx)(`span`,{children:O.check_in})]}),(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`Check-Out Date:`})}),(0,f.jsx)(`span`,{children:O.check_out})]}),(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`strong`,{children:(0,f.jsx)(u,{children:`Total Amount:`})}),(0,f.jsxs)(`span`,{style:{color:`var(--success)`,fontWeight:700},children:[`Rs. `,Number(O.amount).toLocaleString()]})]})]}),(0,f.jsxs)(`div`,{style:{display:`flex`,marginTop:`24px`,justifyContent:`center`},children:[(0,f.jsx)(`button`,{className:`btn btn-outline`,style:{borderRadius:`8px`,padding:`10px 20px`,fontSize:`13px`,marginRight:`8px`},onClick:Lt,disabled:q,children:`Refresh Status`}),(0,f.jsx)(`button`,{className:`btn btn-primary`,style:{borderRadius:`8px`,padding:`10px 20px`,fontSize:`13px`},onClick:()=>{C(!1),v([]),Te(null),Ee(null)},children:`Close`})]})]})})]})]})}),(0,f.jsx)(`style`,{children:`
        /* CUSTOM OVERRIDES FOR KATARAGAMA CIRCUIT BUNGALOW VIEW */
        .bk-hero {
          position: relative;
          min-height: 440px;
          overflow: hidden;
          background: #000;
          display: flex;
          align-items: center;
        }
        .bk-hero-bg {
          position: absolute;
          inset: 0;
          background-color: #26140f;
          background-size: cover;
          background-position: center;
          opacity: 0.55;
        }
        .bk-hero-overlay {
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, rgba(26,20,16,.92) 0%, rgba(139,26,26,.55) 60%, rgba(26,20,16,.6) 100%);
        }
        .bk-hero-inner {
          position: relative;
          z-index: 2;
          max-width: var(--container-max);
          margin: 0 auto;
          padding: 72px 24px;
          display: grid;
          grid-template-columns: 1.2fr 1fr;
          gap: 48px;
          align-items: center;
          width: 100%;
        }
        .bk-hero-eyebrow {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: .14em;
          text-transform: uppercase;
          color: var(--gold-light);
          background: rgba(201,162,39,0.15);
          border: 1px solid rgba(201,162,39,0.3);
          border-radius: 100px;
          padding: 6px 14px;
          display: inline-block;
        }
        .bk-hero-title {
          font-size: clamp(28px, 4vw, 48px);
          font-weight: 800;
          color: #fff;
          line-height: 1.15;
          margin-bottom: 14px;
        }
        .bk-hero-title em {
          color: var(--gold-light);
          font-style: italic;
        }
        .bk-hero-desc {
          font-size: 14.5px;
          color: rgba(255, 255, 255, 0.8);
          line-height: 1.7;
          margin-bottom: 28px;
          max-width: 520px;
        }
        .bk-stats-row {
          display: flex;
          gap: 28px;
          flex-wrap: wrap;
        }
        .bk-stat {
          text-align: left;
        }
        .bk-stat-num {
          font-size: 24px;
          font-weight: 800;
          color: var(--gold-light);
        }
        .bk-stat-lbl {
          font-size: 11px;
          color: rgba(255,255,255,0.6);
          font-weight: 600;
          letter-spacing: .04em;
          display: block;
          margin-top: 2px;
        }
        .bk-hero-gallery {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }
        .bk-gallery-img {
          border-radius: 12px;
          overflow: hidden;
          background: rgba(255,255,255,.05);
          border: 1px solid rgba(201,162,39,.2);
        }
        .bk-gallery-img img {
          width: 100%;
          height: 274px;
          object-fit: cover;
          display: block;
          transition: transform .4s;
        }
        .bk-gallery-img:hover img {
          transform: scale(1.05);
        }

        /* USER ROLE SELECTOR */
        .role-selector-sec {
          background: #f7f5f2;
          border-bottom: 1px solid var(--mid-gray);
        }
        .role-selector-inner {
          max-width: var(--container-max);
          margin: 0 auto;
          padding: 20px 24px;
        }
        .role-row {
          display: flex;
          align-items: center;
          gap: 12px;
          flex-wrap: wrap;
        }
        .role-label {
          font-size: 12.5px;
          font-weight: 700;
          color: var(--text-dark);
          letter-spacing: .06em;
          text-transform: uppercase;
        }
        .role-btn {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 10px 20px;
          border-radius: 100px;
          border: 2px solid var(--mid-gray);
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          background: #fff;
          color: var(--text-body);
          transition: all .25s;
        }
        .role-btn:hover {
          border-color: var(--crimson);
          color: var(--crimson);
        }
        .role-btn.active {
          background: var(--crimson);
          border-color: var(--crimson);
          color: #fff;
          box-shadow: var(--shadow-crimson);
        }
        .role-badge {
          font-size: 10px;
          padding: 2px 8px;
          border-radius: 100px;
          font-weight: 700;
          letter-spacing: .05em;
        }
        .role-btn.active .role-badge {
          background: rgba(255,255,255,.2);
          color: #fff;
        }
        .role-btn .role-badge {
          background: rgba(139,0,0,.08);
          color: var(--crimson);
        }
        #roleEmployee.active {
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          border-color: var(--crimson);
        }

        /* MAIN BOOKING LAYOUT */
        .booking-layout {
          display: grid;
          grid-template-columns: 1fr 380px;
          gap: 36px;
          align-items: start;
        }

        /* AVAILABILITY CALENDAR */
        .avail-card {
          background: #fff;
          border-radius: var(--radius-md);
          border: 1px solid var(--mid-gray);
          overflow: hidden;
          box-shadow: var(--shadow-sm);
        }
        .avail-head {
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          padding: 22px 24px;
          color: #fff;
        }
        .avail-head-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 6px;
        }
        .avail-nav {
          display: flex;
          gap: 6px;
        }
        .avail-nav-btn {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          border: 1.5px solid rgba(255,255,255,.3);
          background: rgba(255,255,255,.1);
          color: #fff;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background .2s;
        }
        .avail-nav-btn:hover {
          background: rgba(255,255,255,.25);
        }
        .avail-month-label {
          font-size: 13px;
          color: rgba(255,255,255,.7);
          letter-spacing: .04em;
          text-transform: uppercase;
          font-weight: 700;
        }
        .avail-legend {
          display: flex;
          gap: 16px;
          margin-top: 12px;
          flex-wrap: wrap;
        }
        .avail-dot {
          width: 10px;
          height: 10px;
          border-radius: 50%;
          flex-shrink: 0;
        }
        .avail-legend-item {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: rgba(255,255,255,.8);
        }
        .cal-grid {
          padding: 20px 24px;
        }
        .cal-dow {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 4px;
          margin-bottom: 8px;
        }
        .cal-dow span {
          text-align: center;
          font-size: 11px;
          font-weight: 700;
          color: var(--text-muted);
          letter-spacing: .06em;
          padding: 6px 0;
          text-transform: uppercase;
        }
        .cal-days {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 4px;
        }
        .cal-day {
          aspect-ratio: 1.2;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          position: relative;
          transition: all .2s;
          border: 1.5px solid transparent;
        }
        .cal-day.empty {
          cursor: default;
        }
        .cal-day.available {
          background: rgba(26,127,90,.08);
          color: var(--success);
          border-color: rgba(26,127,90,.2);
        }
        .cal-day.available:hover {
          background: rgba(26,127,90,.18);
          transform: scale(1.08);
        }
        .cal-day.partial {
          background: rgba(217,119,6,.08);
          color: var(--warning);
          border-color: rgba(217,119,6,.2);
        }
        .cal-day.partial:hover {
          background: rgba(217,119,6,.18);
          transform: scale(1.08);
        }
        .cal-day.booked {
          background: rgba(139,0,0,.06);
          color: var(--text-muted);
          cursor: not-allowed;
          border-color: rgba(139,0,0,.1);
        }
        .cal-day.today {
          box-shadow: 0 0 0 2px var(--gold);
        }
        .cal-day.selected {
          background: var(--crimson)!important;
          color: #fff!important;
          border-color: var(--crimson)!important;
          box-shadow: var(--shadow-crimson);
        }
        .cal-day.checkout-day {
          background: var(--gold)!important;
          color: #fff!important;
          border-color: var(--gold)!important;
        }
        .cal-day.in-range {
          background: rgba(139,0,0,.08);
          border-color: transparent;
        }
        .cal-day.user-blocked {
          cursor: not-allowed;
          opacity: .55;
          filter: grayscale(.4);
        }
        .cal-day.user-blocked:hover {
          transform: none!important;
          background: inherit!important;
        }
        .cal-user-notice {
          margin: 0 24px 18px;
          padding: 10px 14px;
          background: rgba(139,0,0,.04);
          border: 1px solid rgba(139,0,0,.15);
          border-radius: 8px;
          font-size: 12px;
          color: var(--crimson);
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .avail-detail-row {
          padding: 0 24px 20px;
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }
        .avail-room-chip {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 600;
          border: 1.5px solid #eee;
        }
        .chip-green { background: rgba(26,127,90,.04); color: var(--success); border-color: rgba(26,127,90,.15); }
        .chip-orange { background: rgba(217,119,6,.04); color: var(--warning); border-color: rgba(217,119,6,.15); }
        .chip-red { background: rgba(139,0,0,.04); color: var(--crimson); border-color: rgba(139,0,0,.1); }

        /* ROOM LISTINGS */
        .rooms-sec {
          margin-top: 32px;
        }
        .rooms-sec-head h3 {
          font-size: 20px;
          font-weight: 800;
          color: var(--text-dark);
          margin-bottom: 16px;
        }
        .rooms-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 18px;
        }
        .room-card {
          background: #fff;
          border-radius: var(--radius-md);
          border: 1.5px solid var(--mid-gray);
          overflow: hidden;
          transition: var(--transition);
          cursor: pointer;
          display: flex;
          flex-direction: column;
        }
        .room-card:hover {
          box-shadow: var(--shadow-md);
          border-color: rgba(139,0,0,.2);
          transform: translateY(-3px);
        }
        .room-card.selected-room {
          border-color: var(--crimson);
          box-shadow: 0 0 0 3px rgba(139,0,0,.12);
        }
        .room-img {
          width: 100%;
          height: 140px;
          object-fit: cover;
        }
        .room-img-placeholder {
          width: 100%;
          height: 140px;
          background: linear-gradient(135deg, var(--light-gray), var(--off-white));
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .room-body {
          padding: 16px;
          flex: 1;
          display: flex;
          flex-direction: column;
        }
        .room-name {
          font-size: 15px;
          font-weight: 700;
          color: var(--text-dark);
        }
        .room-meta {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          margin-bottom: 12px;
        }
        .room-meta-item {
          display: flex;
          align-items: center;
          gap: 4px;
          font-size: 11px;
          color: var(--text-muted);
          background: var(--off-white);
          padding: 3px 8px;
          border-radius: 4px;
        }
        .room-price-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-top: auto;
        }
        .room-price {
          font-size: 18px;
          font-weight: 800;
          color: var(--crimson);
        }
        .room-select-btn {
          width: 100%;
          margin-top: 12px;
          padding: 8px;
          border-radius: 6px;
          border: 1.5px solid var(--crimson);
          background: #fff;
          color: var(--crimson);
          font-size: 12px;
          font-weight: 700;
          transition: all 0.2s;
        }
        .room-select-btn:hover, .room-card.selected-room .room-select-btn {
          background: var(--crimson);
          color: #fff;
        }

        /* BOOKING SIDEBAR */
        .booking-sidebar {
          display: flex;
          flex-direction: column;
          gap: 20px;
          position: sticky;
          top: 120px;
        }
        .bk-summary-card {
          background: #fff;
          border-radius: var(--radius-md);
          border: 1px solid var(--mid-gray);
          overflow: hidden;
          box-shadow: var(--shadow-sm);
        }
        .bk-sum-head {
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          padding: 18px 22px;
          color: #fff;
        }
        .bk-sum-body {
          padding: 20px 22px;
        }
        .bk-sum-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 10px 0;
          border-bottom: 1px solid var(--light-gray);
          font-size: 13px;
        }
        .bk-sum-row:last-child {
          border-bottom: none;
        }
        .bk-sum-label {
          color: var(--text-muted);
          font-weight: 500;
        }
        .bk-sum-value {
          color: var(--text-dark);
          font-weight: 600;
          text-align: right;
          max-width: 60%;
        }
        .bk-sum-total {
          background: var(--off-white);
          border-radius: 8px;
          padding: 12px 16px;
          margin-top: 12px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .bk-sum-total-label {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-body);
        }
        .bk-sum-total-val {
          font-size: 20px;
          font-weight: 800;
          color: var(--crimson);
        }
        .bk-proceed-btn {
          width: 100%;
          margin-top: 16px;
          padding: 12px;
          border-radius: 8px;
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          color: #fff;
          border: none;
          font-size: 14px;
          font-weight: 700;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          transition: var(--transition);
        }
        .bk-proceed-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: var(--shadow-crimson);
        }
        .bk-proceed-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .bk-trust-items {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .bk-trust-item {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 11.5px;
          color: var(--text-muted);
        }

        /* FACILITIES */
        .facilities-sec {
          background: var(--off-white);
        }
        .facilities-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 20px;
        }
        .facility-card {
          background: #fff;
          border-radius: var(--radius-md);
          padding: 24px 20px;
          text-align: center;
          border: 1px solid var(--mid-gray);
          transition: var(--transition);
        }
        .facility-card:hover {
          box-shadow: var(--shadow-md);
          border-color: rgba(139,0,0,.1);
          transform: translateY(-4px);
        }
        .facility-icon {
          font-size: 2.2rem;
          margin-bottom: 12px;
          display: block;
        }
        .facility-name {
          font-size: 14.5px;
          font-weight: 700;
          color: var(--text-dark);
          margin-bottom: 6px;
        }
        .facility-desc {
          font-size: 12px;
          color: var(--text-muted);
          line-height: 1.5;
        }

        /* BOOKING FORM MODAL */
        .bk-modal-overlay {
          display: none;
          position: fixed;
          inset: 0;
          z-index: 3500;
          background: rgba(0,0,0,.6);
          backdrop-filter: blur(4px);
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .bk-modal-overlay.open {
          display: flex;
        }
        .bk-modal {
          background: #fff;
          border-radius: 16px;
          max-width: 580px;
          width: 100%;
          max-height: 90vh;
          overflow-y: auto;
          box-shadow: var(--shadow-xl);
          display: flex;
          flex-direction: column;
        }
        .bk-modal-head {
          background: linear-gradient(135deg, var(--crimson-dark), var(--crimson));
          padding: 20px 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          color: #fff;
        }
        .bk-modal-title {
          font-size: 16.5px;
          font-weight: 700;
        }
        .bk-modal-close {
          background: rgba(255,255,255,.15);
          border: none;
          color: #fff;
          width: 28px;
          height: 28px;
          border-radius: 50%;
          cursor: pointer;
          font-size: 13px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .bk-modal-body {
          padding: 24px;
        }
        .bk-steps {
          display: flex;
          margin-bottom: 24px;
          position: relative;
        }
        .bk-steps::before {
          content: '';
          position: absolute;
          top: 15px;
          left: 10%;
          right: 10%;
          height: 2px;
          background: var(--light-gray);
          z-index: 0;
        }
        .bk-step {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          position: relative;
          z-index: 1;
        }
        .bk-step-circle {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          border: 2px solid var(--mid-gray);
          background: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 700;
          color: var(--text-muted);
          transition: all 0.3s;
        }
        .bk-step.active .bk-step-circle {
          background: var(--crimson);
          border-color: var(--crimson);
          color: #fff;
        }
        .bk-step.done .bk-step-circle {
          background: var(--success);
          border-color: var(--success);
          color: #fff;
        }
        .bk-step-label {
          font-size: 10px;
          font-weight: 600;
          color: var(--text-muted);
          text-align: center;
        }
        .bk-step.active .bk-step-label { color: var(--crimson); }
        .bk-step.done .bk-step-label { color: var(--success); }

        .bk-form-group {
          margin-bottom: 14px;
        }
        .bk-form-label {
          display: block;
          font-size: 11.5px;
          font-weight: 700;
          color: var(--text-dark);
          margin-bottom: 4px;
        }
        .bk-form-input, .bk-form-select {
          width: 100%;
          padding: 10px 12px;
          border: 1.5px solid var(--mid-gray);
          border-radius: 8px;
          font-size: 13px;
          color: var(--text-body);
          background: #fff;
          outline: none;
          box-sizing: border-box;
        }
        .bk-form-input:focus, .bk-form-select:focus {
          border-color: var(--crimson);
        }
        .bk-form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
        }
        .bk-form-hint {
          font-size: 10.5px;
          color: var(--text-muted);
          margin-top: 2px;
        }
        .bk-btn-row {
          display: flex;
          gap: 12px;
          margin-top: 20px;
        }
        .bk-btn-next, .bk-btn-back, .bk-btn-submit {
          padding: 11px 20px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          border: none;
          transition: all 0.2s;
        }
        .bk-btn-next {
          background: var(--crimson);
          color: #fff;
          flex: 1;
        }
        .bk-btn-next:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .bk-btn-back {
          background: var(--off-white);
          color: var(--text-body);
          border: 1.5px solid var(--mid-gray);
        }

        /* PAYMENT SECTION */
        .pay-methods {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
          margin-bottom: 16px;
        }
        .pay-method {
          padding: 10px;
          border-radius: 8px;
          border: 1.5px solid var(--mid-gray);
          cursor: pointer;
          text-align: center;
          transition: all 0.2s;
        }
        .pay-method:hover { border-color: var(--crimson); }
        .pay-method.active { border-color: var(--crimson); background: rgba(139,0,0,.03); }
        .pay-method-icon { font-size: 1.5rem; margin-bottom: 2px; display: block; }
        .pay-method-label { font-size: 11px; font-weight: 700; }

        .card-preview {
          background: linear-gradient(135deg, #1f2937, #111827);
          border-radius: 12px;
          padding: 18px;
          color: #fff;
          margin-bottom: 14px;
          position: relative;
          overflow: hidden;
          box-shadow: var(--shadow-md);
        }
        .card-preview::before {
          content: '';
          position: absolute;
          top: -20px;
          right: -20px;
          width: 100px;
          height: 100px;
          border-radius: 50%;
          background: rgba(255,255,255,0.03);
        }
        .card-chip {
          width: 32px;
          height: 24px;
          background: linear-gradient(135deg, var(--gold), var(--gold-light));
          border-radius: 4px;
          margin-bottom: 12px;
        }
        .card-number {
          font-size: 15px;
          letter-spacing: 0.18em;
          font-weight: 700;
          margin-bottom: 12px;
          font-family: monospace;
        }
        .card-info-row {
          display: flex;
          justify-content: space-between;
        }
        .card-holder, .card-expiry {
          font-size: 9px;
          color: rgba(255,255,255,.5);
          text-transform: uppercase;
          letter-spacing: .06em;
        }
        .pay-card-fields {
          background: var(--off-white);
          border-radius: 10px;
          padding: 14px;
          margin-bottom: 14px;
          border: 1px solid var(--mid-gray);
        }
        .pay-card-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }

        /* SUCCESS INVOICE */
        .bk-success {
          text-align: center;
          padding: 10px 0;
        }
        .bk-success-icon {
          animation: scaleIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        @keyframes scaleIn { from{transform:scale(0.5);opacity:0;} to{transform:scale(1);opacity:1;} }
        .bk-ref-box {
          background: rgba(26,127,90,.03);
          border: 1.5px dashed rgba(26,127,90,.3);
          border-radius: 10px;
          padding: 14px 20px;
          margin: 18px 0;
        }
        .bk-ref-label {
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          color: var(--success);
          letter-spacing: 0.08em;
        }
        .bk-ref-num {
          font-size: 22px;
          font-weight: 800;
          color: var(--text-dark);
          letter-spacing: 0.05em;
        }
        .bk-success-details {
          background: var(--off-white);
          border-radius: 10px;
          padding: 12px 16px;
          text-align: left;
          border: 1px solid var(--mid-gray);
        }
        .bk-success-details div {
          display: flex;
          justify-content: space-between;
          padding: 6px 0;
          border-bottom: 1px solid var(--light-gray);
          font-size: 12.5px;
        }
        .bk-success-details div:last-child {
          border-bottom: none;
        }

        /* RESPONSIVE LAYOUT OVERRIDES */
        @media(max-width: 1024px) {
          .booking-layout { grid-template-columns: 1fr; }
          .bk-hero-inner { grid-template-columns: 1fr; gap: 24px; }
          .bk-hero-gallery { display: none; }
          .facilities-grid { grid-template-columns: 1fr 1fr; }
        }
        @media(max-width: 900px) {
          .bk-availability-grid { grid-template-columns: 1fr !important; gap: 20px !important; }
        }
        @media(max-width: 768px) {
          .rooms-grid { grid-template-columns: 1fr; }
          .facilities-grid { grid-template-columns: 1fr 1fr; }
          .booking-layout { gap: 20px; }
        }
        @media(max-width: 600px) {
          .bk-form-row { grid-template-columns: 1fr !important; gap: 12px !important; }
          .pay-methods { grid-template-columns: 1fr !important; }
        }
        @media(max-width: 640px) {
          .facilities-grid { grid-template-columns: 1fr; }
          .bk-date-row { flex-direction: column !important; gap: 12px !important; }
          .bk-guest-row { flex-direction: column !important; gap: 12px !important; }
          .bk-step-row { flex-direction: column !important; gap: 12px !important; }
          .bk-pay-row { flex-direction: column !important; gap: 10px !important; }
          .bk-confirm-actions { flex-direction: column !important; gap: 12px !important; }
          .bk-confirm-actions a, .bk-confirm-actions button { width: 100% !important; text-align: center !important; justify-content: center !important; }
          .bk-summary-grid { grid-template-columns: 1fr !important; }
          .bk-otp-row { gap: 8px !important; }
          .bk-modal-inner { padding: 24px 16px !important; border-radius: 16px !important; margin: 12px !important; }
        }
        @media(max-width: 480px) {
          .bk-hero { padding: 48px 16px 40px !important; }
          .bk-hero h1 { font-size: clamp(1.5rem, 6vw, 2.5rem) !important; }
          .bk-section-inner { padding: 20px 16px !important; }
          .bk-room-card { padding: 16px !important; }
          .bk-calendar-header { flex-direction: column !important; gap: 8px !important; align-items: flex-start !important; }
          .bk-amenity-tag { font-size: 11px !important; padding: 4px 8px !important; }
          .bk-dates-input-grid { grid-template-columns: 1fr !important; gap: 12px !important; }
        }
      `})]})}export{Se as default};