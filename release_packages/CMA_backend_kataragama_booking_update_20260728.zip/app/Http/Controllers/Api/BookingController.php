<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BungalowRoom;
use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Carbon\CarbonPeriod;

class BookingController extends Controller
{
    /**
     * Get availability states for each date in a range
     */
    public function getAvailability(Request $request)
    {
        // Default to a 6-month window from the start of the current month
        $start = Carbon::now()->startOfMonth();
        $end = Carbon::now()->addMonths(6)->endOfMonth();

        // Only administrator-approved reservations block the public calendar.
        $bookings = Booking::where('status', 'Confirmed')
            ->where('check_in', '<=', $end->toDateString())
            ->where('check_out', '>=', $start->toDateString())
            ->get();

        $availability = [];
        // Generate date periods
        $period = CarbonPeriod::create($start, $end);
        foreach ($period as $date) {
            $dateString = $date->toDateString();
            $bookedCount = 0;

            foreach ($bookings as $b) {
                $checkIn = Carbon::parse($b->check_in)->startOfDay();
                $checkOut = Carbon::parse($b->check_out)->startOfDay();
                $lastOccupied = $checkIn->equalTo($checkOut) ? $checkIn : $checkOut->copy()->subDay();

                // A date is occupied if it lies within [check_in, lastOccupied]
                if ($date->greaterThanOrEqualTo($checkIn) && $date->lessThanOrEqualTo($lastOccupied)) {
                    $bookedCount++;
                }
            }

            if ($bookedCount > 0) {
                $availability[$dateString] = 'booked';
            } else {
                $availability[$dateString] = 'available';
            }
        }

        return response()->json([
            'status' => 'success',
            'data' => $availability
        ]);
    }

    /**
     * Store a new booking submission
     */
    public function store(Request $request)
    {
        $v = Validator::make($request->all(), [
            'guest_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'required|string|max:20',
            'nic' => 'required|string|max:50',
            'employee_id' => 'nullable|string|max:50',
            'unit_number' => 'required|string|max:100',
            'check_in' => 'required|date|after_or_equal:today',
            'check_out' => 'required|date|after_or_equal:check_in',
            'adults' => 'required|integer|min:1|max:20',
            'children' => 'required|integer|min:0|max:20',
            'notes' => 'nullable|string',
            'permanent_address' => 'required|string|max:500',
            'occupation' => 'required|string|max:255',
            'gov_letter' => 'nullable|string|max:255',
            'is_cma_employee' => 'required|boolean',
            'family_count' => 'required|integer|min:0',
            'family_members' => 'nullable|array',
        ]);

        if ($v->fails()) {
            return response()->json(['errors' => $v->errors()], 422);
        }

        $checkIn = Carbon::parse($request->check_in)->toDateTimeString();
        $checkOut = Carbon::parse($request->check_out)->toDateTimeString();
        $room = $request->unit_number;

        $newIn = Carbon::parse($checkIn);
        $newOut = Carbon::parse($checkOut);

        if (Booking::hasConfirmedDateConflict($checkIn, $checkOut)) {
            return response()->json([
                'message' => 'The selected dates have already been approved for another booking. Please select different dates.'
            ], 409);
        }

        $roomRecord = BungalowRoom::where('name', $room)->first();
        if (! $roomRecord) {
            return response()->json(['message' => 'The selected bungalow room is no longer available.'], 422);
        }

        $nights = max(1, $newIn->copy()->startOfDay()->diffInDays($newOut->copy()->startOfDay()));
        $rate = $request->boolean('is_cma_employee') ? $roomRecord->emp_price : $roomRecord->price;
        $amount = (float) $rate * $nights;

        // Save the booking
        $booking = Booking::create([
            'user_id' => $request->user()?->id,
            'guest_name' => $request->guest_name,
            'email' => $request->email,
            'phone' => $request->phone,
            'nic' => $request->nic,
            'employee_id' => $request->employee_id,
            'unit_number' => $room,
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'adults' => $request->adults,
            'children' => $request->children,
            'amount' => $amount,
            'notes' => $request->notes,
            'status' => 'Pending',
            'payment_status' => 'Pending',
            'permanent_address' => $request->permanent_address,
            'occupation' => $request->occupation,
            'gov_letter' => $request->gov_letter,
            'is_cma_employee' => $request->is_cma_employee,
            'family_count' => $request->family_count,
            'family_members' => $request->family_members,
        ]);

        return response()->json([
            'status' => 'success',
            'data' => $booking,
            'message' => 'Your booking request is pending payment and administrator approval.'
        ], 201);
    }

    /**
     * Check a booking without exposing private guest information.
     */
    public function status(Request $request)
    {
        $data = $request->validate([
            'reference_no' => ['required', 'string', 'regex:/^KTGB\d{6}$/i'],
            'phone' => 'required|string|max:20',
        ]);

        $booking = Booking::where('reference_no', strtoupper($data['reference_no']))
            ->where('phone', $data['phone'])
            ->first();

        if (! $booking) {
            return response()->json([
                'message' => 'No booking was found for that reference number and phone number.',
            ], 404);
        }

        return response()->json([
            'status' => 'success',
            'data' => [
                'reference_no' => $booking->reference_no,
                'booking_status' => $booking->status,
                'payment_status' => $booking->payment_status,
                'unit_number' => $booking->unit_number,
                'check_in' => $booking->check_in->toDateString(),
                'check_out' => $booking->check_out->toDateString(),
                'amount' => $booking->amount,
                'message' => match ($booking->status) {
                    'Confirmed' => 'Booking successful. Your reservation has been approved.',
                    'Cancelled' => 'This booking request was not approved. Please contact CMA for assistance.',
                    'Done' => 'This approved stay has been completed.',
                    default => 'Payment and administrator approval are pending.',
                },
            ],
        ]);
    }

    /**
     * Get reservation history for the logged-in citizen
     */
    public function history(Request $request)
    {
        $bookings = Booking::where('user_id', $request->user()->id)
            ->orderByDesc('created_at')
            ->get();

        return response()->json([
            'status' => 'success',
            'data' => $bookings
        ]);
    }
}
