<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'reference_no',
        'user_id',
        'guest_name',
        'email',
        'phone',
        'nic',
        'employee_id',
        'unit_number',
        'check_in',
        'check_out',
        'adults',
        'children',
        'status',
        'payment_status',
        'approved_at',
        'approved_by',
        'amount',
        'notes',
        'permanent_address',
        'occupation',
        'gov_letter',
        'is_cma_employee',
        'family_count',
        'family_members',
    ];

    protected $casts = [
        'check_in' => 'date',
        'check_out' => 'date',
        'amount' => 'decimal:2',
        'is_cma_employee' => 'boolean',
        'family_count' => 'integer',
        'family_members' => 'array',
        'approved_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::created(function (Booking $booking): void {
            if (! $booking->reference_no) {
                $booking->forceFill([
                    'reference_no' => self::referenceForId($booking->id),
                ])->saveQuietly();
            }
        });
    }

    public static function referenceForId(int $id): string
    {
        return 'KTGB'.str_pad((string) $id, 6, '0', STR_PAD_LEFT);
    }

    public static function hasConfirmedDateConflict(string $checkIn, string $checkOut, ?int $ignoreId = null): bool
    {
        $newStart = Carbon::parse($checkIn)->startOfDay();
        $newEnd = Carbon::parse($checkOut)->startOfDay();
        $newLastOccupied = $newStart->equalTo($newEnd) ? $newStart : $newEnd->copy()->subDay();

        return self::query()
            ->where('status', 'Confirmed')
            ->when($ignoreId, fn ($query) => $query->where('id', '!=', $ignoreId))
            ->get(['check_in', 'check_out'])
            ->contains(function (Booking $booking) use ($newStart, $newLastOccupied): bool {
                $existingStart = Carbon::parse($booking->check_in)->startOfDay();
                $existingEnd = Carbon::parse($booking->check_out)->startOfDay();
                $existingLastOccupied = $existingStart->equalTo($existingEnd)
                    ? $existingStart
                    : $existingEnd->copy()->subDay();

                return $newStart->lessThanOrEqualTo($existingLastOccupied)
                    && $existingStart->lessThanOrEqualTo($newLastOccupied);
            });
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
