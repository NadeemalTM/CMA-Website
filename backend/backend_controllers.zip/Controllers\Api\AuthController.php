<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'staff',
        ]);

        $token = $user->createToken('cma-admin')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => [
                'id' => $user->id, 'name' => $user->name, 'email' => $user->email, 
                'phone' => $user->phone, 'nic' => $user->nic, 'role' => $user->role,
                'profile_picture_url' => $user->profile_picture ? asset('storage/' . $user->profile_picture) : null
            ],
        ], 201);
    }

    public function login(Request $request)
    {
        $request->validate(['email' => 'required|email', 'password' => 'required']);
        $user = User::where('email', $request->email)->first();

        if (! $user || ! Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        if ($user->role === 'citizen') {
            throw ValidationException::withMessages([
                'email' => ['Access denied. This portal is for administrative staff only.'],
            ]);
        }

        $token = $user->createToken('cma-admin')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => [
                'id' => $user->id, 'name' => $user->name, 'email' => $user->email, 
                'phone' => $user->phone, 'nic' => $user->nic, 'role' => $user->role,
                'profile_picture_url' => $user->profile_picture ? asset('storage/' . $user->profile_picture) : null
            ],
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logged out successfully.']);
    }

    public function me(Request $request)
    {
        $user = $request->user();
        $userData = $user->toArray();
        $userData['profile_picture_url'] = $user->profile_picture ? asset('storage/' . $user->profile_picture) : null;
        return response()->json(['data' => $userData]);
    }

    public function citizenRegister(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'phone' => 'required|string|max:20',
            'nic' => 'required|string|max:20',
            'password' => 'required|string|min:6',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'nic' => $request->nic,
            'password' => Hash::make($request->password),
            'role' => 'citizen',
        ]);

        $token = $user->createToken('cma-citizen')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => [
                'id' => $user->id, 'name' => $user->name, 'email' => $user->email, 
                'phone' => $user->phone, 'nic' => $user->nic, 'role' => $user->role,
                'profile_picture_url' => $user->profile_picture ? asset('storage/' . $user->profile_picture) : null
            ],
        ], 201);
    }

    public function citizenLogin(Request $request)
    {
        $request->validate(['email' => 'required|email', 'password' => 'required']);
        $user = User::where('email', $request->email)->where('role', 'citizen')->first();

        if (! $user || ! Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        $token = $user->createToken('cma-citizen')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => [
                'id' => $user->id, 'name' => $user->name, 'email' => $user->email, 
                'phone' => $user->phone, 'nic' => $user->nic, 'role' => $user->role,
                'profile_picture_url' => $user->profile_picture ? asset('storage/' . $user->profile_picture) : null
            ],
        ]);
    }

    public function uploadProfilePicture(Request $request)
    {
        $request->validate([
            'profile_picture' => 'required|file|max:5120', // 5MB max
        ]);

        $user = $request->user();

        if ($user->profile_picture) {
            Storage::disk('public')->delete($user->profile_picture);
        }

        $file = $request->file('profile_picture');
        $filename = \Illuminate\Support\Str::random(40) . '.' . ($file->getClientOriginalExtension() ?: 'bin');
        $file->move(storage_path('app/public/profile-pictures'), $filename);
        $path = 'profile-pictures/' . $filename;
        
        $user->profile_picture = $path;
        $user->save();

        $userData = $user->toArray();
        $userData['profile_picture_url'] = asset('storage/' . $path);

        return response()->json([
            'message' => 'Profile picture updated successfully',
            'data' => $userData
        ]);
    }
}
